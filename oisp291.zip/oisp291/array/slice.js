function test1() {
    const months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
    ]
    // console.log(months)
    // console.log(months.slice(0, 6))

    // console.log(months.slice(6, 12))
    // console.log(months.slice(6))
    // console.log(months.slice(-6))

    // console.log(months.reverse())

    const seasons = [
        months.slice(2, 5),
        months.slice(5, 8),
        months.slice(8, 11),
        [months[11], months[0], months[1]],
        // [months[11], ...months.slice(0, 2)],
    ]
    // console.log(seasons)

    console.log(months.join(' '))
}

function test1() {
    const str = 'January February March April May June ' +
    'July August September October November December'
    // console.log(str)

    // const str1 = str.slice(0, 37)
    // const str2 = str.slice(0, 38)
    // console.log(str1)
    // console.log(str2)
    // console.log(str1 === str2)
    // console.log(`"${str1}"`)
    // console.log(`"${str2}"`)

    console.log(str.slice(38))
}

function test() {
    const str = 'January February March April May June ' +
    'July August September October November December'
    console.log(str.split(' '))
}

test()
