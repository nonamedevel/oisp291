/*
    Array methods
*/

function test1() {
    const rgbColors = [
        'red',
        'green',
        'blue',
    ]
    console.log(rgbColors.includes('red'))
    console.log(rgbColors.includes('black'))
}

function test() {
    const menuItems = [
        '<a href="/">Main</a>',
        '<a href="/about">About</a>',
        '<a href="/contacts">Contacts</a>',
    ]
    menuItems.push('<a href="/signup">Sign up</a>')
    const result = `<div class="menu">
${menuItems.join('\n')}
</div>`
    console.log(result)
}

test()
