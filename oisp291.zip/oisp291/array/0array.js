/*
    Array methods
*/

function test() {
    const rgbColors = [
        'red',
        'green',
        'blue',
    ]
    console.log(rgbColors.includes('red'))
    console.log(rgbColors.includes('black'))
}

test()
