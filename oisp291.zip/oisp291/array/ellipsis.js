function test() {
    const fixedEntries = [
        'Show All Commands',
        'Open File',
        'Open Folder',
        'Open Recent',
        'Open Chat',
    ]
    // const randomEntries = []
    const randomEntries = ['something']
    // const entries = [...fixedEntries, ...randomEntries]
    const entries = [fixedEntries, randomEntries]
    console.log(entries)
}

test()