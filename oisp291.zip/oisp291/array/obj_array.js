const products = [
    {
        id: 101,
        category: 'monitor',
        model: 'MSI PRO MP273A',
        price: 9899,
    },
    {
        id: 102,
        category: 'monitor',
        model: 'Xiaomi G27Qi',
        price: 19099,
    },
    {
        id: 103,
        category: 'keyboard',
        model: 'ARDOR GAMING Blade',
        price: 5399,
    },
    {
        id: 104,
        category: 'mouse',
        model: 'ARDOR GAMING Fury',
        price: 1750,
    },
    {
        id: 105,
        category: 'keyboard',
        model: 'Logitech K280E',
        price: 2680,
    },
]

for (const product of products) {
    console.log(product.model)
}
