function test() {
    const colors = [
        'black',
        'blue',
        'cyan',
        'white',
        'green',
        'magenta',
        'yellow',
        'red',
    ]
    const rgbColors = [
        'red',
        'green',
        'blue',
    ]
    const cmyColors = [
        'cyan',
        'magenta',
        'yellow',
    ]
    for (const color of colors) {
        if (rgbColors.includes(color)) {
            console.log(color)
        }
    }
}

test()
