

function test2() {
    class SimpleClass {
        constructor() {
            console.log(123)
        }
    }
    const obj = new SimpleClass()
}

function test3() {
    class SimpleClass {
        printMessage() {
            console.log(456)
        }
    }
    const obj = new SimpleClass()
    obj.printMessage()
}

function test() {
    class SimpleClass {
        static printMessage() {
            console.log(789)
        }
    }
    SimpleClass.printMessage()
}

test()
