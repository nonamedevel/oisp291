function test() {
    class Shape {
        constructor(color) {
            this.color = color
        }
        printName() {
            console.log('Shape')
        }
    }
    class Square extends Shape {
        constructor(color, size) {
            super(color)
            this.size = size
        }
        printName() {
            console.log('Square')
        }
    }
    class Circle extends Shape {
        constructor(color, radius) {
            super(color)
            this.radius = radius
        }
    }
    const shape = new Shape('red')
    shape.printName()
    const square = new Square('green', 20)
    square.printName()
    const circle = new Circle('blue', 30)
    circle.printName()
}

test()
