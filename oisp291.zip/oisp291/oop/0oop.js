/*
    The simplest class
*/
function test1() {
    class SimpleClass {}
}

test()
