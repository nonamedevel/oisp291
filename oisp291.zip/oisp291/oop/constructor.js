function test1() {
    class SimpleClass {
        constructor() {
            console.log(555)
        }
    }
    const obj = new SimpleClass()
}

function test2() {
    class SimpleClass {
        constructor(num) {
            console.log(num)
        }
    }
    const obj1 = new SimpleClass(555)
    const obj2 = new SimpleClass(666)
    const obj3 = new SimpleClass(777)
}

function test3() {
    class Person {
        constructor(name, age) {
            console.log(name, age)
        }
    }
    const person1 = new Person('John', 20)
    const person2 = new Person('Jane', 30)
    const person3 = new Person('Vasya', 40)
}

/*
    Using properties
*/
function test() {
    class Person {
        constructor(name, age) {
            this.name = name
            this.age = age
        }
        printMessage() {
            console.log(this.name, this.age)
        }
    }
    const person1 = new Person('John', 20)
    person1.printMessage()
    const person2 = new Person('Jane', 30)
    person2.printMessage()
    const person3 = new Person('Vasya', 40)
    person3.printMessage()
}

test()
