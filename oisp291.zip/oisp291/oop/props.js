function test1() {
    class Person {
        constructor(name, age) {
            this.name = name
            this.age = age
        }
    }
    const person = new Person('Vasya', 20)
    console.log(person)
    person.age++
    console.log(person)
}

function test1() {
    class Person {
        name = 'Masha'
        age = 30
    }
    const person = new Person()
    console.log(person)
    person.age++
    console.log(person)
}

function test1() {
    class Student {
        program = 'IT'
        constructor(name, age) {
            this.name = name
            this.age = age
        }
    }
    const person1 = new Student('Vasya', 20)
    console.log(person1)
    const person2 = new Student('Masha', 30)
    console.log(person2)
}

function test() {
    class Student {
        static program = 'Cooking'
        constructor(name, age) {
            this.name = name
            this.age = age
        }
        print() {
            console.log(`${this.constructor.name} { program: '${this.constructor.program}', name: '${this.name}', age: ${this.age} }`)
        }
    }
    const person1 = new Student('Vasya', 20)
    person1.print()
    const person2 = new Student('Masha', 30)
    person2.print()
}

test()
