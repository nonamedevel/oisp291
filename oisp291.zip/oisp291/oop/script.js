/*
    Shape           color
        Rectangle   width, height
            Square  size
        Circle      radius
*/

function test() {
    class Shape {
        constructor(color) {
            this.color = color
        }
        printName() {
            console.log('Shape')
        }
    }

    class Rectangle extends Shape{
        constructor(color, width, height){
            super(color)
            this.width = width
            this.height = height
        }
        printName() {
            console.log('Rectangle')
        }
    }

    class Square extends Rectangle {
        constructor(color, size) {
            super(color, size, size)
        }
        printName() {
            console.log('Square')
        }
    }
    class Circle extends Shape {
        constructor(color, radius) {
            super(color)
            this.radius = radius
        }
    }


    const shape = new Shape('red')
    shape.printName()
    const rectangle = new Rectangle('red', 20, 30)
    rectangle.printName()
    const square = new Square('green', 20)
    square.printName()
    const circle = new Circle('blue', 30)
    circle.printName()
}

test()
