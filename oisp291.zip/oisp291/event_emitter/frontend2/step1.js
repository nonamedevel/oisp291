class EventEmitter {
    map = {}
    on(event, callback) {
        this.map[event] = callback
    }
    emit(event, ...args) {
        if (this.map[event]) {
            this.map[event](...args)
        }
    }
}
const myEmitter = new EventEmitter()
myEmitter.on('event', (data) => {
    console.log(data)
})
myEmitter.emit('event', 'hello')
