/*
    Inspired by    
    src\vs\base\common\event.ts
*/

class EventEmitter {
    map = {}
    on(event, callback) {
        this.map[event] = callback
    }
    emit(event, ...args) {
        if (this.map[event]) {
            this.map[event](...args)
        }
    }
}

class Example1 extends EventEmitter {
    constructor() {
        super()
        setTimeout(() => {
            this.emit('event2000', 123)
        }, 2000)
        setTimeout(() => {
            this.emit('event3000', 456)
        }, 3000)
    }
}

class Example2 extends EventEmitter {
    constructor(ex) {
        super()
        ex.on('event2000', (data) => {
            console.log(data)
        })
        ex.on('event3000', (data) => {
            console.log(data)
        })
    }
}

const example1 = new Example1()
const example2 = new Example2(example1)
