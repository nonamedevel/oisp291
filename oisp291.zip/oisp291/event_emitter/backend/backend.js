const EventEmitter = require('node:events')

function test1() {
    class MyEmitter extends EventEmitter {}
    
    const myEmitter = new MyEmitter()
    myEmitter.on('event', () => {
        console.log('an event occurred!')
    })
    myEmitter.emit('event')
}

function test() {    
    const myEmitter = new EventEmitter()
    myEmitter.on('event', (data) => {
        console.log(data)
    })
    myEmitter.emit('event', 'no inheritance!')
}

test()
