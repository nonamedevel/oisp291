
/*
    enum TreeItemCollapsibleState {
        None = 0,
        Collapsed = 1,
        Expanded = 2
    }
*/



function test1() {
    var TreeItemCollapsibleState;
    (function (TreeItemCollapsibleState) {
        TreeItemCollapsibleState[TreeItemCollapsibleState["None"] = 0] = "None";
        TreeItemCollapsibleState[TreeItemCollapsibleState["Collapsed"] = 1] = "Collapsed";
        TreeItemCollapsibleState[TreeItemCollapsibleState["Expanded"] = 2] = "Expanded";
    })(TreeItemCollapsibleState || (TreeItemCollapsibleState = {}));
}

function test() {
    const TreeItemCollapsibleState = {
        None: 0,
        Collapsed: 1,
        Expanded: 2,
    }

    console.log(TreeItemCollapsibleState.None)
    console.log(TreeItemCollapsibleState.Collapsed)
    console.log(TreeItemCollapsibleState.Expanded)
}

test()
