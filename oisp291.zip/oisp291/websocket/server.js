const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })

wss.on('connection', function(ws) {
    ws.on('error', console.error)
    
    ws.on('message', function(data) {
        console.log('received', data)
    })

    ws.send('something')
})
