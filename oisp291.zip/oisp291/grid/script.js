const container = document.querySelector('.container')
const rowCount = 4
const colCount = 3
for (let i = 0; i < rowCount; i++) {
    const row = document.createElement('div')
    row.classList.add('row')
    container.append(row)
    for (let j = 0; j < colCount; j++) {
        const cell = document.createElement('div')
        cell.textContent = 0
        cell.classList.add('cell')
        row.append(cell)
    }
}