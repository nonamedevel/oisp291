const container = document.querySelector('.container')
const rowCount = 4
const colCount = 3
/*
    Uint8Array:
        u - unsigned
        int - integer
        8 - 8 bits (256 possible combinations)
*/
const view = new Uint8Array(rowCount * colCount)
let index = 0
for (let i = 0; i < rowCount; i++) {
    const row = document.createElement('div')
    row.classList.add('row')
    container.append(row)
    for (let j = 0; j < colCount; j++) {
        const cell = document.createElement('div')
        cell.textContent = view[index]
        cell.dataset.index = index
        index++
        cell.classList.add('cell')
        row.append(cell)
    }
}
function getIndex1(target) {
    let index = 0
    for (let i = 0; i < rowCount; i++) {
        const row = container.children[i]
        for (let j = 0; j < colCount; j++) {
            if (target === row.children[j]) {
                return index
            }
            index++
        }
    }
}
function getIndex2(target) {
    return Number(target.dataset.index)
}
container.addEventListener('click', function(event) {
    const index = getIndex2(event.target)
    if (index === undefined) {
        return
    }
    console.log(index)
    view[index] = 1 - view[index]
    event.target.textContent = view[index]
    // console.log(view)
    // console.log(event.target)
})
