const container = document.querySelector('.container')
const rowCount = 4
const colCount = 5
/*
    Uint8Array:
        u - unsigned
        int - integer
        8 - 8 bits (256 possible combinations)
*/
const view = new Uint8Array(rowCount * colCount)
let index = 0
const elemToIndexMap = new Map()
for (let i = 0; i < rowCount; i++) {
    const row = document.createElement('div')
    row.classList.add('row')
    container.append(row)
    for (let j = 0; j < colCount; j++) {
        const cell = document.createElement('div')
        cell.classList.add('cell')
        row.append(cell)
        cell.dataset.index = index
        cell.textContent = view[index]
        elemToIndexMap.set(cell, index)
        index++
    }
}
function getIndex1(elem) {
    let index = 0
    for (let i = 0; i < rowCount; i++) {
        const row = container.children[i]
        for (let j = 0; j < colCount; j++) {
            if (elem === row.children[j]) {
                return index
            }
            index++
        }
    }
}
function getIndex2(elem) {
    return Number(elem.dataset.index)
}
function getIndex3(elem) {
    return elemToIndexMap.get(elem)
}
container.addEventListener('click', function(event) {
    if (!event.target.classList.contains('cell')) {
        return
    }
    const index = getIndex3(event.target)
    view[index] = 1 - view[index]
    event.target.textContent = view[index]
})
