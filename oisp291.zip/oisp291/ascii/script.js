function createCell(textContent, color) {
    const cell = document.createElement('div')
    cell.textContent = textContent
    cell.style.backgroundColor = color
    container.append(cell)
}
const container = document.querySelector('.ascii_table')
for (let i = 0; i < 32; i++) {
    createCell(i.toString(16), 'orange')
}
for (let i = 32; i < 127; i++) {
    createCell(String.fromCharCode(i), 'green')
}
createCell((127).toString(16), 'orange')