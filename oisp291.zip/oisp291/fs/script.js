/*
    https://nodejs.org/docs/latest/api/fs.html
*/
const fs = require('fs')

/*
    Read buffer
*/
function test1() {
    fs.readFile('D:/oisp291/fs/example.txt', function(err, data) {
        console.log(data)
    })
}

/*
    Read Unicode string
*/
function test2() {
    fs.readFile('D:/oisp291/fs/example.txt', 'utf8', function(err, data) {
        console.log(data)
    })
}

/*
    Relative path vs Absolute path
*/
function test3() {
    // const pathToFile = 'D:/oisp291/fs/example.txt' // absolute path
    const pathToFile = 'example.txt' // relative path
    // const pathToFile = 'fs/example.txt' // relative path
    fs.readFile(pathToFile, 'utf8', function(err, data) {
        console.log(data)
    })
}

/*
    Remove file
*/
function test4() {
    const pathToFile = 'D:/oisp291/fs/example.txt'
    fs.unlink(pathToFile, function(err) {
        if (err) throw err
        console.log('done')
    })
}

function test() {
    const pathToFile = 'D:/oisp291/fs/example.txt'
    const data = 'Example data'
    fs.writeFile(pathToFile, data, function(err) {
        if (err) throw err
        console.log('done')
    })
}

test()
