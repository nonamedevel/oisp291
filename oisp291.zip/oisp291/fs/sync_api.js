const fs = require('fs')

/*
    Read buffer
*/
function test1() {
    try {
        const data = fs.readFileSync('C:/oisp291/fs/example.txt')
        console.log(data)
    } catch(err) {
        console.log(err)
    }
}

/*
    Read Unicode string
*/
function test1() {
    try {
        const data = fs.readFileSync('C:/oisp291/fs/example.txt', 'utf8')
        console.log(data)
    } catch(err) {
        console.log(err)
    }
}

function test() {
    const pathToFile = 'C:/oisp291/fs/example.txt'
    const data = 'Example data'
    try {
        fs.writeFileSync(pathToFile, data)
    } catch(err) {
        console.log(err)
    }
    console.log('done')
}

test()
