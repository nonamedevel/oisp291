const cart = {};

// получаю элементы со страницы, чтобы потом с ними работать
const list = document.querySelector('#product-list');     
const cartItems = document.querySelector('#cart-items');  
const totalPrice = document.querySelector('#total-price'); 
const clearBtn = document.querySelector('#clear-cart');  

// запрашиваю у сервера список товаров
fetch('/product')
  .then(r => r.json()) // преобразую ответ из формата JSON в обычный JS-объект
  .then(products => {
    // прохожусь по каждому товару и создаю карточку на странице
    products.forEach(p => {
      const card = document.createElement('div'); 
      card.className = 'product'; // добавляю класс для оформления

      // вставляю внутрь карточки картинку, название, модель, цену и кнопку
      card.innerHTML = `
        <img src="/images${p.id}.jpeg" alt="${p.name}">
        <h3>${p.name}</h3>
        <p>${p.model}</p>
        <p>${p.price} ₽</p>
        <button>Добавить</button>
      `;

      // при клике по кнопке "Добавить" вызывается функция addToCart()
      card.querySelector('button').onclick = () => addToCart(p);

      // добавляю готовую карточку в общий список товаров
      list.appendChild(card);
    });
  });

// функция добавления товара в корзину
function addToCart(p) {
  // ключ формирую по названию и модели, чтобы отличать похожие товары
  const key = `${p.name} - ${p.model}`;

  // если товар уже есть — просто увеличиваю количество
  // если нет — добавляю его с количеством 1
  cart[key] ? cart[key].qty++ : cart[key] = { price: p.price, qty: 1 };

  // обновляю корзину, чтобы сразу показать изменения на экране
  renderCart();
}

// функция обновления корзины 
function renderCart() {
  cartItems.innerHTML = ''; // очищаю старый список товаров
  let total = 0; // переменная для подсчёта общей суммы

  // прохожусь по всем товарам, которые лежат в корзине
  for (let key in cart) {
    const item = cart[key];
    const li = document.createElement('li'); // создаю элемент списка <li>

    // считаю сумму за каждый товар (цена * количество)
    const sum = item.price * item.qty;

    // записываю в строку название, количество и сумму
    li.textContent = `${key} × ${item.qty} — ${sum} ₽`;

    // добавляю строку в список
    cartItems.appendChild(li);

    // прибавляю к общей сумме
    total += sum;
  }

  // показываю итоговую сумму внизу корзины
  totalPrice.textContent = total;

  // если корзина пустая — кнопка очистки неактивна
  clearBtn.disabled = !Object.keys(cart).length;
}

// функция для очистки корзины
function clearCart() {
  // удаляю все товары из объекта cart
  for (let key in cart) delete cart[key];

  // обновляю корзину
  renderCart();
}

clearBtn.onclick = clearCart;