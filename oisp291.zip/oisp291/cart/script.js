const http = require('http')
const fs = require('fs')

const products = [
    {
        id: 101,
        category: 'monitor',
        model: 'MSI PRO MP273A',
        price: 9899,
    },
    {
        id: 102,
        category: 'monitor',
        model: 'Xiaomi G27Qi',
        price: 19099,
    },
    {
        id: 103,
        category: 'keyboard',
        model: 'ARDOR GAMING Blade',
        price: 5399,
    },
    {
        id: 104,
        category: 'mouse',
        model: 'ARDOR GAMING Fury',
        price: 1750,
    },
    {
        id: 105,
        category: 'keyboard',
        model: 'Logitech K280E',
        price: 2680,
    },
]

const server = http.createServer(function(req, res) {
    if (req.url === '/') {
        fs.readFile('D:/oisp291/cart/index.html', function(err, data) {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else if (req.url === '/products') {
        res.writeHead(200, {
            'Content-Type': 'application/json'
        })
        res.end(JSON.stringify(products))
    } else {
        res.writeHead(404, {
            'Content-Type': 'text/html'
        })
        res.end(`<h1>404 Not found</h1>`)
    }
})

server.listen(4000)