function checkNumber(number) {
    if (number > 0) {
        console.log('Число положительное!')
    } else if (number < 0) {
        console.log('Число отрицательное!')
    } else {
        console.log('Число равно 0')
    }
}
checkNumber(15)
checkNumber(-3)
checkNumber(0)