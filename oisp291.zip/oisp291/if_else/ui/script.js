const container = document.querySelector('#container')
const input = container.querySelector('#input')
const info = container.querySelector('#text')
const btn = container.querySelector('#btn')
const roll = container.querySelector('#roll')
const rundbutton = container.querySelector('#rund-num')

roll.addEventListener('click', function() {
    rundbutton.textContent = Math.floor(Math.random() * 100);
})
btn.addEventListener('click', function () {
    const number = input.value
    if (number > 0) {
        info.textContent = 'Число положительное!'
    } else if (number < 0) {
        info.textContent = 'Число отрицательное!'
    } else {
        info.textContent = 'Число равно 0'
    }
})

