/*
    (1) Создать структуру данных для хранения информации о файлах и папках
    (2) Напечатать названия файлов используя эту структуру данных

    (3) Добавить HTML и CSS для отображения информации в этой структуре данных
    У вложенных файлов и папок должны быть отступы
*/

const list = ['example4.txt', 'example5.txt', {
    name: "dir1",
    children: [

    ]
},
{
    name: 'dir2',
    children: [
        'example10.txt',
        {
            name: 'dir3',
            children: [
                'example7.txt',
                'example8.txt',
                'example9.txt'
            ],
        }
    ]
},
{
    name: "dir4",
    children: [
        'example1.txt',
        'example2.txt',
        'example6.txt'
    ]
},
{
    name: 'dir5',
    children: [
        'example3.txt'
    ]
}
]

const treeView = document.querySelector('.tree_view')

function rekyrsia (arr, container){
    for (let i=0; i<arr.length; i++){
        if (typeof arr[i] === 'string'){
            const cell = document.createElement('div')
            cell.textContent = arr[i]
            container.append(cell)
        }
        else {
            console.log(arr[i].name)
            const innerContainer = document.createElement('div')
            // innerContainer.textContent = arr[i]
            container.append(innerContainer)
            rekyrsia(arr[i].children, innerContainer)
        }
    }
}
// debugger
rekyrsia(list, treeView)