function test1() {
    const obj = {
        id: 101,
        category: 'monitor',
        model: 'MSI PRO MP273A',
        price: 9899,
    }
    console.log(obj)
    console.log(typeof obj)
    const str = JSON.stringify(obj)
    console.log(str)
    console.log(typeof str)
}

function test() {
    const str = `{
        "id":101,
        "category":"monitor",
        "model":"MSI PRO MP273A",
        "price":9899
    }`
    console.log(str)
    console.log(typeof str)
    const obj = JSON.parse(str)
    console.log(obj)
    console.log(typeof obj)
}

test()