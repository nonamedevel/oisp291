class FruitWidget {
    constructor() {
        this.container = document.querySelector('.fruit_widget')
        this.input = this.container.querySelector('input')
        this.clearButton = this.container.querySelector('.clear_button')
        this.clearButton.onclick = this.clearFruits.bind(this)
        this.addButton = this.container.querySelector('.add_fruit')
        this.addButton.onclick = this.addFruit.bind(this)
        this.fruitList = this.container.querySelector('.fruit_list')

        this.selectedFruit = null

        this.dbName = 'example55'
        this.db = null
        const req = indexedDB.open(this.dbName)
        req.onsuccess = (event) => {
            this.db = req.result
            this.populateList()
        }
        req.onupgradeneeded = function () {
            console.log('onupgradeneeded')
            req.result.createObjectStore('fruits', {
                keyPath: 'name'
            })
        }
        this.fruitList.addEventListener('click', this.onClick.bind(this))
    }
    onClick(event) {
        if (!event.target.classList.contains('fruit')) {
            return
        }
        if (this.selectedFruit) {
            this.selectedFruit.style.background = ''
            if (this.selectedFruit === event.target) {
                this.selectedFruit = null
            } else {
                this.selectedFruit = event.target
                event.target.style.background = 'green'
            }
        } else {
            this.selectedFruit = event.target
            event.target.style.background = 'green'
        }
    }
    populateList() {
        return new Promise((res, rej) => {
            const tx = this.db.transaction('fruits', 'readwrite')
            const store = tx.objectStore('fruits')
            const req = store.getAll()
            req.onsuccess = (event) => {
                for (const fruit of req.result) {
                    const fruitElem = document.createElement('div')
                    fruitElem.classList.add('fruit')
                    fruitElem.textContent = fruit.name
                    this.fruitList.append(fruitElem)
                }
            }
        })
    }
    addFruit() {
        const tx = this.db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        const req = store.add({ name: this.input.value })
        req.onsuccess = (event) => {
            this.fruitList.innerHTML = ''
            this.input.value = ''
            this.populateList()
        }
    }
    clearFruits() {
        const tx = this.db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        const storeReq = store.clear()
        storeReq.onsuccess = (event) => {
            this.fruitList.innerHTML = ''
        }
    }
}

const fruitWidget = new FruitWidget()
