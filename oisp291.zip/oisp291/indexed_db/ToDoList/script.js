class FruitWidget {
    constructor() {
        this.container = document.querySelector('.fruit_widget')
        this.input = this.container.querySelector('input')
        this.clearButton = this.container.querySelector('.clear_button')
        this.clearButton.onclick = this.clearFruits.bind(this)
        this.addButton = this.container.querySelector('.add_fruit')
        this.addButton.onclick = this.addFruit.bind(this)
        this.fruitList = this.container.querySelector('.fruit_list')
        
        this.fruitList.addEventListener('keydown', (event) => {
            if (event.code === 'ArrowUp'){
                if (this.selectedFruit.previousElementSibling){
                    this.selectedFruit.style.background = ""
                    this.selectedFruit = this.selectedFruit.previousElementSibling
                    this.selectedFruit.style.background = "green"
                }
            } else if (event.code === 'ArrowDown'){
                if (this.selectedFruit.nextElementSibling){
                    this.selectedFruit.style.background = ""
                    this.selectedFruit = this.selectedFruit.nextElementSibling
                    this.selectedFruit.style.background = "green"
                }
            } else if (event.code === 'Home'){
                this.selectedFruit.style.background = ""
                this.selectedFruit = this.fruitList.firstElementChild
                this.selectedFruit.style.background = "green"
            } else if (event.code === 'End'){
                this.selectedFruit.style.background = ""
                this.selectedFruit = this.fruitList.lastElementChild
                this.selectedFruit.style.background = "green"
            }
        }) 

        this.selectedFruit = null

        this.dbName = 'example55'
        this.db = null
        const req = indexedDB.open(this.dbName)
        req.onsuccess = (event) => {
            this.db = req.result
            this.populateList()
        }
        req.onupgradeneeded = function () {
            console.log('onupgradeneeded')
            req.result.createObjectStore('fruits', {
                keyPath: 'name'
            })
        }
        this.fruitList.addEventListener('click', this.onClick.bind(this))
    }

    deleteSingleEl() {
        const tx = this.db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        const req = store.delete(this.selectedFruit.textContent)
        req.onsuccess = (event) => {
            this.selectedFruit.remove()
            this.selectedFruit = null
        }
    }
    onClick(event) {
        if (!event.target.classList.contains('fruit')) {
            return
        }
        if (this.selectedFruit) {
            this.selectedFruit.style.background = ''
            if (this.selectedFruit === event.target) {
                this.selectedFruit = null
            } else {
                this.selectedFruit = event.target
                event.target.style.background = 'green'
            }
        } else {
            this.selectedFruit = event.target
            event.target.style.background = 'green'
        }
    }
    populateList() {
        return new Promise((res, rej) => {
            const tx = this.db.transaction('fruits', 'readwrite')
            const store = tx.objectStore('fruits')
            const req = store.getAll()
            req.onsuccess = (event) => {
                for (const fruit of req.result) {
                    const fruitElem = document.createElement('div')
                    fruitElem.classList.add('fruit')
                    fruitElem.textContent = fruit.name
                    this.fruitList.append(fruitElem)
                }
            }
        })
    }
    addFruit() {
        const tx = this.db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        const req = store.add({ name: this.input.value })
        req.onsuccess = (event) => {
            this.fruitList.innerHTML = ''
            this.input.value = ''
            this.populateList()
        }
    }
    clearFruits() {
        if (this.selectedFruit) {
            this.deleteSingleEl()
        } else {
            const tx = this.db.transaction('fruits', 'readwrite')
            const store = tx.objectStore('fruits')
            const storeReq = store.clear()
            storeReq.onsuccess = (event) => {
                this.fruitList.innerHTML = ''
            }
        }
    }
}

const fruitWidget = new FruitWidget()
