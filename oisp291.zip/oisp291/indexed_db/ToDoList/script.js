const input = document.querySelector('input')
const addButton = document.querySelector('.add_fruit')
const listFruits = document.querySelector('.list_fruit')


function openDB() {
    return new Promise(function(res, rej) {
        const req = indexedDB.open('example5')
        req.onsuccess = function(event) {
            res(req.result)
        }
    })
}
function populateList(db) {
    return new Promise(function(res, rej) {
        const tx = db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        const req = store.getAll()
        req.onsuccess = function(event) {
            for(const fruit of req.result) {
                const fruitElem = document.createElement('div')
                fruitElem.textContent = fruit.name
                listFruits.append(fruitElem)
            }
        }
    })
}
function addFruit(db) {
    return new Promise(function(res, rej) {
        const tx = db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        const req = store.add({name: input.value})
        req.onsuccess = function(event) {
            const fruitElem = document.createElement('div')
            fruitElem.textContent = input.value
            input.value = ''
            listFruits.append(fruitElem)
        }
    })
}
async function main() {
    const db = await openDB()
    populateList(db)
    addButton.onclick = function() {
        addFruit(db)
    }
}
main()
// const req = indexedDB.open('example5')
// req.onsuccess = function(event) {
//     const db = req.result
//     const tx = db.transaction('fruits', 'readwrite')
//     const store = tx.objectStore('fruits')
//     const storeReq = store.add({name: 'pear'})
//     const storeReq = store.getAll()
//     const storeReq = store.delete('pear')
//     storeReq.onsuccess = function() {
//         console.log(storeReq.result)
        

//     }
//     console.log(storeReq)
//     tx.onerror = function() {
//         console.log(tx.error)
//     }
//     tx.oncomplete = function() {
//         console.log('done')
//     }
// }
// req.onerror = function(err) {
//     console.log(err)
// }
// req.onupgradeneeded = function() {
//     console.log('onupgradeneeded')
//     req.result.createObjectStore('fruits', {
//         keyPath: 'name'
//     })
// }

