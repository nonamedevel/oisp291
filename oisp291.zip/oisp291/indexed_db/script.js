function test() {
    const req = indexedDB.open('example1')
    // console.log(req)
    // console.log(req.readyState)
    req.onsuccess = function(event) {
        console.log(event.target.result)
        console.log(req.result)
    }
    req.onerror = function(err) {
        console.log(err)
    }
}

test()
