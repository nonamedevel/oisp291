function test1() {
    const req = indexedDB.open('example1')
    // console.log(req)
    // console.log(req.readyState)
    req.onsuccess = function(event) {
        console.log(event.target.result)
        console.log(req.result)
        console.log(req.result === event.target.result)
    }
    req.onerror = function(err) {
        console.log(err)
    }
}

function test() {
    const req = indexedDB.open('example4')
    req.onsuccess = function(event) {
        const db = req.result
        const tx = db.transaction('fruits', 'readwrite')
        const store = tx.objectStore('fruits')
        // const storeReq = store.add({name: 'pear'})
        const storeReq = store.getAll()
        // const storeReq = store.delete('pear')
        storeReq.onsuccess = function() {
            console.log(storeReq.result)
        }
        console.log(storeReq)
        tx.onerror = function() {
            console.log(tx.error)
        }
        tx.oncomplete = function() {
            console.log('done')
        }
    }
    req.onerror = function(err) {
        console.log(err)
    }
    req.onupgradeneeded = function() {
        console.log('onupgradeneeded')
        req.result.createObjectStore('fruits', {
            keyPath: 'name'
        })
    }
}

test()
