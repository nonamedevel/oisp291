const path = require('path')

function test1() {
    console.log(process.env['APPDATA'])
    console.log(process.env['VSCODE_APPDATA'])
    console.log(process.platform)
}

function test() {
    const appDataPath = process.env['APPDATA']
    const productName = 'Code'
    const result = path.join(appDataPath, productName)
    console.log(result)
}

test()
