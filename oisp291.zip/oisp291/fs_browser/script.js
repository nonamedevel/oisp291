
// const handle = window.showOpenFilePicker()
// console.log(handle)

const button = document.querySelector('.click_me')
button.addEventListener('click', async function() {
    try {
        const [handle] = await window.showOpenFilePicker()
        console.log(handle)
        const file = await handle.getFile()
        console.log(file)
        const content = await file.text()
        console.log(content)
    } catch(err) {
        if (err.name === 'AbortError') {
            return
        }
        console.log(err)
    }
})