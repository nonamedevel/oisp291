function test1() {
    throw new Error('Something went wrong')
    console.log('The end')
}

function test() {
    try {
        throw new Error('Something went wrong')
    } catch(err) {
        console.log(err)
    }
    console.log('The end')
}

test()
