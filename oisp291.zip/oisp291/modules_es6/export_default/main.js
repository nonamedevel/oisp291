import compare from './library.js'

function main() {
    const result = compare(2, 3)
    // const result = compare(3, 2)
    // const result = compare(3, 3)
    console.log(result)
}

main()
