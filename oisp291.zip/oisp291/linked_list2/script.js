class Node {
    constructor(data) {
        this.data = data
        this.next = null
    }
}

class OneLinkedList {
    constructor() {
        this.head = this.tail = null
    }

    popFront() {
        if (this.head === null) { return }
        if (this.head === this.tail) { this.head = this.tail = null; return }
        let node = this.head
        this.head = node.next
    }

    pushBack(...data) {
        for (let item of data){
            let node = new Node(item)
            if (this.head === null) {
                this.head = node
            }
            if (this.tail !== null) {
                this.tail.next = node
            }
            this.tail = node
        }
    }

    getAt(k) {
        if (k < 0) { return null }
        let node = this.head
        let n = 0
        while (node && n !== k) {
            node = node.next
            n++
        }
        return (n === k) ? node : null
    }

    popEl(delData) {
        if (this.head === null) return

        if (this.head.data === delData) {
            this.popFront()
            return
        }

        let current = this.head
        while (current.next !== null && current.next.data !== delData) {
            current = current.next
        }

        if (current.next === null) return

        let nodeToDelete = current.next
        current.next = nodeToDelete.next

        if (nodeToDelete === this.tail) {
            this.tail = current
        }
    }
}

function log_link_list(list) {
    let current = list.head
    while (current !== null) {
        console.log(current.data)
        current = current.next
    }
}

function test1() {
    let listt = new OneLinkedList()
    listt.pushBack("apple")
    listt.pushBack('banana')
    listt.pushBack('kiwi')
    log_link_list(listt)
    listt.popEl('kiwi')

    log_link_list(listt)
}

function test() {
    let list1 = new OneLinkedList()
    list1.pushBack('apple', 'orange', 'banana', 'mango', 'kiwi')
    log_link_list(list1)
    debugger
    list1.popEl('orange')
    log_link_list(list1)
}

test()