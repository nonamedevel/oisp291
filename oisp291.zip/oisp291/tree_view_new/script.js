const rootItem = {
  name: 'root',
  children: [
    'example4.txt',
    'example5.txt',
    { name: 'dir1', children: [] },
    {
      name: 'dir2',
      children: [
        'example10.txt',
        {
          name: 'dir3',
          children: ['example7.txt', 'example8.txt', 'example9.txt']
        }
      ]
    },
    { name: 'dir4', children: ['example1.txt', 'example2.txt', 'example6.txt'] },
    { name: 'dir5', children: ['example3.txt'] }
  ]
}

function printFiles(node) {
  if (typeof node === 'string') {
    console.log(node)
  } else {
    node.children.forEach(item => printFiles(item))
  }
}

function draw(node, container, level = 0) {
  if (typeof node === 'string') {
    const fileElem = document.createElement('div')
    fileElem.textContent = node
    fileElem.style.marginLeft = level * 15 + 'px'
    container.append(fileElem)
  } else {
    const detailsElem = document.createElement('details')
    detailsElem.open = true
    detailsElem.style.marginLeft = level * 10 + 'px'
    container.append(detailsElem)

    const summaryElem = document.createElement('summary')
    summaryElem.textContent = node.name
    detailsElem.append(summaryElem)
  
    const innerElem = document.createElement('div')
    innerElem.classList.add('inner')
    detailsElem.append(innerElem)

    for (const item of node.children) {
      draw(item, innerElem, level + 1)
    }
  }
}

const treeView = document.querySelector('.tree_view')
draw(rootItem, treeView)
printFiles(rootItem)
