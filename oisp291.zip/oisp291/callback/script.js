/*
    Function type is the "first class citizen" in JavaScript
*/
function test1() {
    function func(callback) {
        callback()
    }
    func(function() {
        console.log('hello there!')
    })
}

function test() {
    function func() {
        return function() {
            console.log('hello there!!!')
        }
    }
    // func()()
    const printHello = func()
    printHello()
}

test()