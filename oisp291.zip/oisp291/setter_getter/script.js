function test1() {
    class Person {
        constructor(name, age) {
            this.name = name
            this.age = age
        }
        getAge() {
            return this.age
        }
        setAge(age) {
            this.age = age
        }
    }
    
    const person = new Person('Vasya', 20)
    console.log(person.age)
    console.log(person.getAge())
}

function test() {
    class Person {
        constructor(name, age) {
            this.name = name
            this._age = age
        }
        get age() {
            console.log('getting age')
            return this._age
        }
        set age(age) {
            console.log('setting age')
            this._age = age
        }
    }
    
    const person = new Person('Vasya', 20)
    console.log(person.age)
    console.log('---------------')
    // person.age++
    // person.age = person.age + 1
    person.age += 1
    console.log('---------------')
    console.log(person.age)
}

test()
