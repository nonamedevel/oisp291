/*
(1) Create an array of 5 random numbers.
(2) Print the largest number in this array.
*/
function test(){
    const array = []
    for (let i = 0; i < 5; i++) {
        array.push(Math.random())
    }
    let max = 0 
    console.log(array)
    for (const item of array){
        if (item > max){
            max = item
        }
    }
    console.log(max)
}
test()
    