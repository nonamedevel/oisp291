/*
    Написать функцию которая будет
    на основе массива fileNames создавать 2 массива:
    jsFiles и cssFiles
*/

const fileNames = [
    'main.js',
    'Widget1.js',
    'Widget1.css',
    'Widget2.js',
    'Widget2.css',
    'Widget3.js',
    'Widget3.css',
]
