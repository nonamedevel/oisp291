class Cart{
  constructor() {
    this.cart = {};
    
    // получаю элементы со страницы, чтобы потом с ними работать
    this.list = document.querySelector('#product-list');     
    this.cartItems = document.querySelector('#cart-items');  
    this.totalPrice = document.querySelector('#total-price'); 
    this.clearBtn = document.querySelector('#clear-cart');  

    // запрашиваю у сервера список товаров
    fetch('/product')
      .then(r => r.json()) // преобразую ответ из формата JSON в обычный JS-объект
      .then(this.createCard.bind(this));
      
      this.clearBtn.onclick = this.clearCart.bind(this);
    }
    
    createCard(products) {
      // прохожусь по каждому товару и создаю карточку на странице
      for (const p of products) {
        const card = document.createElement('div'); 
        card.className = 'product'; // добавляю класс для оформления

        // вставляю внутрь карточки картинку, название, модель, цену и кнопку
        card.innerHTML = `
          <img src="/images${p.id}.jpeg" alt="${p.name}">
          <h3>${p.name}</h3>
          <p>${p.model}</p>
          <p>${p.price} ₽</p>
          <button>Добавить</button>
        `;

        // при клике по кнопке "Добавить" вызывается функция addToCart()
        card.querySelector('button').onclick = () => this.addToCart(p);

        // добавляю готовую карточку в общий список товаров
        this.list.appendChild(card);
      }
    }
    
    // функция добавления товара в корзину
    addToCart(p) {
      // ключ формирую по названию и модели, чтобы отличать похожие товары
      const key = `${p.name} - ${p.model}`;
      
      // если товар уже есть — просто увеличиваю количество
      // если нет — добавляю его с количеством 1
      this.cart[key] ? this.cart[key].qty++ : this.cart[key] = { price: p.price, qty: 1 };
      
      // обновляю корзину, чтобы сразу показать изменения на экране
      this.renderCart();
    }
    
    // функция обновления корзины 
    renderCart() {
      this.cartItems.innerHTML = ''; // очищаю старый список товаров
      let total = 0; // переменная для подсчёта общей суммы
      
      // прохожусь по всем товарам, которые лежат в корзине
      for (let key in this.cart) {
        const item = this.cart[key];
        const li = document.createElement('li'); // создаю элемент списка <li>
        
        // считаю сумму за каждый товар (цена * количество)
        const sum = item.price * item.qty;
        
      // записываю в строку название, количество и сумму
      li.textContent = `${key} × ${item.qty} — ${sum} ₽`;
  
      // добавляю строку в список
      this.cartItems.appendChild(li);
  
      // прибавляю к общей сумме
      total += sum;
    }
  
    // показываю итоговую сумму внизу корзины
    this.totalPrice.textContent = total;
  
    // если корзина пустая — кнопка очистки неактивна
    this.clearBtn.disabled = !Object.keys(this.cart).length;
  }
  
  // функция для очистки корзины
  clearCart() {
    // удаляю все товары из объекта cart
    for (let key in this.cart) delete this.cart[key];
  
    // обновляю корзину
    this.renderCart();
  }
};

const cart = new Cart()
