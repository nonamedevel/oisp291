const http = require('http');
const fs = require('fs');
const path = require('path');

class Server {
  constructor() {
    // сервер будет отправлять эти данные при запросе на /product
    this.products = [
      { id: 101, name: 'monitor', model: 'MSI PRO MP273A', price: 9389, src: 'resources/images101.jpeg' },
      { id: 102, name: 'monitor', model: 'Xiaomi G27Qi', price: 11839, src: 'resources/images102.jpeg' },
      { id: 103, name: 'keyboard', model: 'ARDOR GAMING Blade', price: 5198, src: 'resources/images103.jpeg' },
      { id: 104, name: 'mouse', model: 'Logitech G PRO X SUPERLIGHT 2', price: 3543, src: 'resources/images104.jpeg' },
      { id: 105, name: 'keyboard', model: 'Logitech MX Keys S', price: 7389, src: 'resources/images105.jpeg' }
    ];
    const imgfiles = [
      'jpeg',
      'png',
      'jpg',
      'webp',
    ]

    http.createServer((req, res) => {
      // вывожу в консоль запрос, чтобы видеть, что запрашивает браузер
      console.log(req.method, req.url);

      // если пользователь зашёл на главную страницу
      if (req.url === '/' || req.url === '/index.html') {
        // отправляю index.html
        return this.sendFile(res, 'index.html', 'text/html; charset=utf-8');
      }

      // если браузер запрашивает файл со скриптом
      if (req.url === '/script.js') {
        // отправляю script.js
        return this.sendFile(res, 'script.js', 'text/javascript; charset=utf-8');
      }

      // если запрошен список товаров 
      if (req.url === '/product') {
        // отправляю массив products в формате JSON
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify(this.products));
      }

      const arr = req.url.split('.')
      // если запросили картинку
      if (arr.length === 2 && imgfiles.includes(arr[1])) {
        console.log('123')
        // отправляю изображение
        return this.sendFile(res, 'resources' + req.url, arr[1]);
      }

      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Страница не найдена');

    }).listen(4000, () => {
      console.log('Сервер запущен: http://localhost:4000');
    });
  }

  // функция, чтобы отправлять файлы пользователю 
  sendFile(res, fileName, type) {
    const file = path.join(__dirname, fileName)
    fs.readFile(file, (err, data) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('Файл не найден');
      }
      res.writeHead(200, { 'Content-Type': type });
      res.end(data);
    });
  }




}


const server = new Server()