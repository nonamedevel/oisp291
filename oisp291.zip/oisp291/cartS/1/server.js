const http = require('http');
const fs = require('fs');
const path = require('path');

// сервер будет отправлять эти данные при запросе на /product
const products = [
  { id: 101, name: 'monitor',  model: 'MSI PRO MP273A', price: 9389 },
  { id: 102, name: 'monitor',  model: 'Xiaomi G27Qi',   price: 11839 },
  { id: 103, name: 'keyboard', model: 'ARDOR GAMING Blade', price: 5198 },
  { id: 104, name: 'mouse',    model: 'Logitech G PRO X SUPERLIGHT 2', price: 3543 },
  { id: 105, name: 'keyboard', model: 'Logitech MX Keys S', price: 7389 }
];

// функция, чтобы отправлять файлы пользователю 
function sendFile(res, file, type) {
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Файл не найден');
    }
    res.writeHead(200, { 'Content-Type': type });
    res.end(data);
  });
}

http.createServer((req, res) => {
  // вывожу в консоль запрос, чтобы видеть, что запрашивает браузер
  console.log(req.method, req.url);

  // если пользователь зашёл на главную страницу
  if (req.url === '/' || req.url === '/index.html') {
    // отправляю index.html
    return sendFile(res, path.join(__dirname, 'index.html'), 'text/html; charset=utf-8');
  }

  // если браузер запрашивает файл со скриптом
  if (req.url === '/script.js') {
    // отправляю script.js
    return sendFile(res, path.join(__dirname, 'script.js'), 'text/javascript; charset=utf-8');
  }

  // если запрошен список товаров 
  if (req.url === '/product') {
    // отправляю массив products в формате JSON
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(products));
  }

  // если запросили картинку
  if (/^\/images\d+\.(jpe?g|png)$/i.test(req.url)) {
    // вырезаю первый слэш и получаю путь к файлу
    const filePath = path.join(__dirname, req.url.slice(1));
    const type = req.url.endsWith('.jpeg')
    // отправляю изображение
    return sendFile(res, filePath, type);
  }

  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('404 Страница не найдена');

}).listen(4000, () => {
  console.log('Сервер запущен: http://localhost:4000');
});