const http = require("http")
const fs = require("fs")


const server = http.createServer(function(request, response) { 
    if (request.url === "/") {
        fs.readFile("index.html", function(err, data) {
            if (err) {
                throw err
            }
            response.writeHead(200, {
                "Content-Type": "text/html"
            })
            response.end(data)
        })
    } else {
        response.writeHead(404, {
                "Content-Type": "text/html"
            })
        response.end("<h1>404 NotFound</h1>")
    }
})

server.listen(5624)