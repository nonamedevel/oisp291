function test1() {
    for (let i = 0; i < 5; i++) {
        console.log(i)
    }
}

function test1() {
    let i = 0
    while (i < 5) {
        console.log(i)
        i++
    }
}

function test() {
    const fruits = [
        'orange', 'apple', 'mango'
    ]
    // for (const fruit of fruits) {
    //     console.log(fruit)
    // }
    for (let i = 0; i < fruits.length; i++) {
        console.log(fruits[i])
    }
}

test()
