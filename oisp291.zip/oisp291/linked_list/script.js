function test() {
    function removeItem1(origArr, item) {
        return origArr.filter(arg => arg !== item)
    }
    function removeItem1(origArr, item) {
        let index = origArr.indexOf(item)
        return [...origArr.slice(0, index), ...origArr.slice(index + 1)]
    }
    function removeItem(origArr, item) {
        let index = origArr.indexOf(item)
        origArr.splice(index, 1)
        return origArr
    }
    function removeItem1(origArr, item) {
        const newArr = []
        for (let i = 0; i < origArr.length; i++) {
            if (origArr[i] !== item) {
                newArr.push(origArr[i])
            }
        }
        return newArr
    }
    let fruits = ['apple', 'orange', 'banana', 'mango', 'kiwi']
    fruits = removeItem(fruits, 'orange')
    console.log(fruits)
}

test()
