function test() {
    const colors = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
    }
    // console.log(colors)
    // for (const key of Object.keys(colors)) {
    //     console.log(key)
    // }
    // for (const value of Object.values(colors)) {
    //     console.log(value)
    // }
    for (const [key, value] of Object.entries(colors)) {
        console.log(key, value)
    }
}

/*
    Not recommended
*/
function test() {
    const colors = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
    }
    for (const item in colors) {
        console.log(item)
    }
}


test()
