function test1() {
    function print(msg) {
        console.log(msg)
    }
    print('hello')
}

function test1() {
    function print() {
        console.log(this.msg)
    }
    const boundPrint = print.bind({msg: 'hello'})
    boundPrint()
}

function test1() {
    const obj = {
        msg: 'hello',
        // print() {
        //     console.log(this.msg)
        // }
        print: function() {
            console.log(this.msg)
        }
    }
    obj.print()
}

function test1() {
    class Example {
        constructor() {
            this.value = 123
            this.func2 = this.func2.bind(this)
        }
        func1(func) {
            func()
        }
        func2() {
            console.log(111, this)
        }
    }
    const obj = new Example()
    // obj.func2()
    obj.func1(obj.func2)
}

function test1() {
    const obj = {
        msg: 'hello',
        // print: function() {
        //     console.log(this.msg)
        // }
        print: () => {
            console.log(this)
        }
    }
    obj.print()
}

function test() {
    function print() {
        // const consoleLog = () => {
        //     console.log(this.msg)
        // }
        const consoleLog = function() {
            console.log(this)
        }
        consoleLog()
    }
    const boundPrint = print.bind({msg: 'hello'})
    boundPrint()
}

test()
