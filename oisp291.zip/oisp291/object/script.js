function test() {
    const colors = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
    }
    console.log(colors)
    // console.log(colors.green)
    // console.log(colors.black)
}

function test1() {
    const colors = {}
    colors.red = 'красный'
    colors.green = 'зеленый'
    colors.blue = 'синий'
    console.log(colors.green)
    console.log(colors.black)
}

function test1() {
    const colors = {}
    colors['red'] = 'красный'
    colors['green'] = 'зеленый'
    colors['blue'] = 'синий'
    console.log(colors.blue)
    console.log(colors.white)
}

/*
    this.routes[route] = callback
*/
function test1() {
    const this_routes = {}
    let route

    route = 'red'
    this_routes[route] = 'red callback'
    route = 'green'
    this_routes[route] = 'green callback'
    route = 'blue'
    this_routes[route] = 'blue callback'

    console.log(this_routes.blue)
    console.log(this_routes.white)
}

function test1() {
    const this_routes = {}
    let route

    route = 'red'
    this_routes[route] = () => 'Red callback'
    route = 'green'
    this_routes[route] = () => 'Green callback'
    route = 'blue'
    this_routes[route] = () => 'Blue callback'

    console.log(this_routes.blue && this_routes.blue())
    console.log(this_routes.white && this_routes.white())
}

function test1() {
    const colors = {
        red: function() {
            console.log('красный')
        },
        green: function() {
            console.log('зеленый')
        },
        blue: function() {
            console.log('синий')
        },
    }
    if (colors.green) {
        colors.green()
    }
    if (colors.black) {
        colors.black()
    } else {
        console.log('color not found')
    }
}

test()
