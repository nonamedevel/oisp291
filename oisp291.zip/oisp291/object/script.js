function test1() {
    const colors = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
    }
    console.log(colors.green)
    console.log(colors.black)
}

function test() {
    const colors = {
        red: function() {
            console.log('красный')
        },
        green: function() {
            console.log('зеленый')
        },
        blue: function() {
            console.log('синий')
        },
    }
    if (colors.green) {
        colors.green()
    }
    if (colors.black) {
        colors.black()
    } else {
        console.log('color not found')
    }
}

test()
