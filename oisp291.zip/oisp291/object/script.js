function test1() {
    const colors = {
        red: 'красный',
        green: 'зеленый',
        blue: 'синий',
    }
    console.log(colors.green)
    console.log(colors.black)
}

function test1() {
    const colors = {}
    colors.red = 'красный'
    colors.green = 'зеленый'
    colors.blue = 'синий'
    console.log(colors.green)
    console.log(colors.black)
}

function test() {
    const colors = {}
    colors['red'] = 'красный'
    colors['green'] = 'зеленый'
    colors['blue'] = 'синий'
    console.log(colors.blue)
    console.log(colors.while)
}

function test1() {
    const colors = {
        red: function() {
            console.log('красный')
        },
        green: function() {
            console.log('зеленый')
        },
        blue: function() {
            console.log('синий')
        },
    }
    if (colors.green) {
        colors.green()
    }
    if (colors.black) {
        colors.black()
    } else {
        console.log('color not found')
    }
}

test()
