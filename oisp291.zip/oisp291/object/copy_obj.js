/*
    Problem
*/
function test1() {
    class Example {
        constructor(opts) {
            this.opts = opts
        }
        printInfo() {
            console.log(this.opts.num)
        }
    }
    const obj = {
        num: 123
    }
    const example = new Example(obj)
    example.printInfo()
    obj.num = 456
    example.printInfo()
}

/*
    Solution #1
*/
function test1() {
    class Example {
        constructor(opts) {
            this.num = opts.num
        }
        printInfo() {
            console.log(this.num)
        }
    }
    const obj = {
        num: 123
    }
    const example = new Example(obj)
    example.printInfo()
    obj.num = 456
    example.printInfo()
}

/*
    Solution #2
*/
function test() {
    class Example {
        constructor(opts) {
            this.opts = JSON.parse(JSON.stringify(opts))
        }
        printInfo() {
            console.log(this.opts.num)
        }
    }
    const obj = {
        num: 123
    }
    const example = new Example(obj)
    example.printInfo()
    obj.num = 456
    example.printInfo()
}

test()
