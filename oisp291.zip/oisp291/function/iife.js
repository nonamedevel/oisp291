function test1() {
    function print(arg) {
        console.log(arg)
    }
    print('hello')
}

/*
    Immediately invoked function expression
    Функциональное выражение которое вызывается сразу же
*/
function test() {
    (function(arg) {
        console.log(arg)
    })('hello!')
}

test()
