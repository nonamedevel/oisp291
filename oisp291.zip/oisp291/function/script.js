function func() {
    console.log('vanilla function')
}
func()

class Example {
    method() {
        console.log('method inside class')
    }
}
const ex = new Example()
ex.method()

