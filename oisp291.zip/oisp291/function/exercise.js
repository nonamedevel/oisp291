function button (){
    const btn = document.createElement("button")
    btn.textContent = "кнопка"
    btn.addEventListener('click', function() {
        btn.textContent += '*'
    })
    document.body.append(btn)
}
button()