function test1() {
    function server(port) { // port is a parameter
        console.log(port)
    }
    server(4000) // 4000 is an argument
}

function test1() {
    function server(port, delay) {
        console.log('port', port)
        console.log('delay', delay)
    }
    server(4000, 2000)
}

function test1() {
    function server(opts) {
        console.log('port', opts.port)
        console.log('delay', opts.delay)
    }
    server({
        delay: 2000,
        port: 4000,
    })
}

function test() {
    const opts = {
        delay: 2000,
        port: 4000,
    }
    console.log('port', opts.port)
    console.log('delay', opts.delay)
}

test()
