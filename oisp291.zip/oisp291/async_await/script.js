function test1() {
    const promise = new Promise(function(res, rej) {
        setTimeout(function() {
            res(98)
        }, 2000)
    })
    promise.then(function(num) {
        console.log(num + 2)
    }).catch(function(err) {
        console.log(err)
    })
}

function test() {
    function asyncTask() {
        return new Promise(function(res, rej) {
            setTimeout(function() {
                res(198)
            }, 1000)
        })
    }
    asyncTask().then(function(num) {
        console.log(num + 2)
    }).catch(function(err) {
        console.log(err)
    })
}

function test1() {
    function asyncTask() {
        return new Promise(function(res, rej) {
            setTimeout(function() {
                res(198)
            }, 1000)
        })
    }
    async function main() {
        try {
            const num = await asyncTask()
            console.log(num + 2)
        } catch(err) {
            console.log(err)
        }
    }
    main()
}

test()
