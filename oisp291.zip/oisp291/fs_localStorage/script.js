class LocalStorageFS {
    constructor() {
        this.data = null
    }
    readLocalStorage() {
        const str = localStorage.getItem('tiny_fs')
        if (str) {
            this.data = JSON.parse(str)
        } else {
            this.data = {
                name: '<root>',
                children: []
            }
        }
    }
    writeLocalStorage() {
        const str = JSON.stringify(this.data)
        localStorage.setItem('tiny_fs', str)
    }
    readFile(fileName, callback) {
        this.readLocalStorage()
        for (const item of this.data.children) {
            if (item.name === fileName) {
                callback(null, item.data)
                return
            }
        }
        callback(new Error("file not found"))
    }
    writeFile(fileName, data, callback) {
        this.readLocalStorage()
        let done
        for (const item of this.data.children) {
            if (item.name === fileName) {
                item.data = data
                done = true
                break
            }
        }
        if (!done) {
            this.data.children.push({
                name: fileName,
                data,
            })
        }
        this.writeLocalStorage()
        callback()
    }
    appendFile(fileName, data, callback) {
        this.readLocalStorage()
        let done
        for (const item of this.data.children) {
            if (item.name === fileName) {
                item.data += data
                done = true
                break
            }
        }
        if (!done) {
            this.data.children.push({
                name: fileName,
                data,
            })
        }
        this.writeLocalStorage()
        callback()
    }
    unlink(fileName, callback){
        this.readLocalStorage() 
        const arr=[]
        for (const item of this.data.children) {
            if (item.name !== fileName) {
                arr.push(item)
            }
        }
        this.data.children = arr
        this.writeLocalStorage()
        callback()
    }
}

function test1() {
    const fs = new LocalStorageFS()
    const data = Date() + '\n'
    fs.writeFile('iiii.txt', data, function (err) {
        console.log('done')
    })
}

function test1() {
    const fs = new LocalStorageFS()
    const data = Date() + '\n'
    fs.appendFile('example.txt', data, function (err) {
        console.log('done')
    })
}

function test1() {
    const fs = new LocalStorageFS()
    fs.readFile('example.txt', function (err, data) {
        if (err) {
            console.log(err)
            return
        }
        console.log(data)
    })
}

function test() {
    const fs = new LocalStorageFS()
    fs.unlink('444.txt', function (err) {
        if (err) {
            console.log(err)
            return
        }
        console.log('done')
    })
}

test()
