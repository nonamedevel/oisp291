class GetNumbers{
    generator(){
       let numbers = []
       for (let i = 0; i<9; i++){
            numbers.push(Math.floor(Math.random()*100))
       }
    //    console.log(numbers)
       let chotnoe = []
       let nechotnoe = []
       for (const number of numbers){
           if (number % 2 === 0){
                chotnoe.push(number)
           } else{
                nechotnoe.push(number)
           }
       }
       console.log(chotnoe)
       console.log(nechotnoe)
    }
}
const getgenerator = new GetNumbers()
getgenerator.generator()