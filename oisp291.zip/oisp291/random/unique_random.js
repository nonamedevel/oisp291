/*
    Generate 10 unique random number in range from 0 to 100
*/
