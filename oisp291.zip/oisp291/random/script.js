function test1() {
    const view = new Uint8Array(32)
    console.log(view)
}

function test1() {
    const view = new Uint8Array(32)
    for (let i = 0; i < 32; i++) {
        view[i] = 36
    }
    console.log(view)
}
/*
    0.6921069767017474
    6.921069767017474
    6
*/
function test1() {
    // console.log(Math.random())
    // console.log(Math.random())
    // console.log(Math.random())
    console.log(Math.floor(0.6921069767017474 * 10))
}

/*
    Random integers
*/
function test1() {
    console.log(Math.floor(Math.random() * 10))
    console.log(Math.floor(Math.random() * 10))
    console.log(Math.floor(Math.random() * 10))
}

function test1() {
    const view = new Uint8Array(32)
    for (let i = 0; i < 32; i++) {
        view[i] = Math.random()
    }
    console.log(view)
}

function test() {
    const view = new Uint8Array(32)
    for (let i = 0; i < 32; i++) {
        view[i] = Math.floor(Math.random() * 256)
    }
    console.log(view)
}

test()
