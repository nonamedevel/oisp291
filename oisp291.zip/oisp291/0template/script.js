function test() {
    console.log(123)
}

test()
