
// placeholders
class EditorBooleanOption{
    constructor(id, name, defaultValue, schema) {
        this.schema = schema
    }
}
const EditorOption = {}
const nls = {
    localize(param1, param2) {
        return param2
    }
}
function register(param) {
    return param
}
const DOM = {
    append(parent, child) {
        parent.append(child)
        return child
    }
}
function $(selector) {
    const elem = document.createElement('div')
    elem.classList.add(selector.slice(1))
    return elem
}

// src\vs\editor\common\config\editorOptions.ts
const EditorOptions = {
	folding: register(new EditorBooleanOption(
		EditorOption.folding, // id
        'folding', // name
        true, // defaultValue
		{ // schema
            description: nls.localize(
                'folding', 
                "Controls whether the editor has code folding enabled."
            ) 
        }
	)),
}


// src\vs\workbench\contrib\preferences\browser\settingsTree.ts
class SettingBoolRenderer {
    renderTemplate() {
        const container = document.body
        const descriptionAndValueElement = DOM.append(
            container, 
            $('.setting-item-value-description')
        )

        const controlElement = DOM.append(
            descriptionAndValueElement, 
            $('.setting-item-bool-control')
        )

        const checkbox = new Toggle({
            actionClassName: 'setting-value-checkbox'
        })
        controlElement.append(checkbox.domNode)
        checkbox.onChange(() => {
            console.log(checkbox.domNode.checked)
        })

        const descriptionElement = DOM.append(
            descriptionAndValueElement,
            $('.setting-item-description')
        )

        descriptionElement.textContent = EditorOptions.folding.schema.description
    }
}

// src\vs\base\browser\ui\toggle\toggle.ts
class Toggle {
    constructor(opts) {
        this._opts = opts
        
        this.domNode = document.createElement('input')
        const classes = ['monaco-custom-toggle']
        this.domNode.classList.add(classes[0])
        this.domNode.classList.add(opts.actionClassName)
        this.domNode.type = 'checkbox'
    }
    onChange(callback) {
        this.domNode.addEventListener('input', callback)
    }
}

// entry point
const settingBoolRenderer = new SettingBoolRenderer()
settingBoolRenderer.renderTemplate()
