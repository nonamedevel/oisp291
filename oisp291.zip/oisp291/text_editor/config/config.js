/*
    C:\Users\<username>\AppData\Roaming\Code\User\settings.json
    %APPDATA%\Code\User\settings.json

    C:\Users\<username>\AppData\Roaming

    "editor.cursorBlinking": "solid"

    Ctrl + Shift + P

    workbench.action.openGlobalSettings
    workbench.action.openRawDefaultSettings
    workbench.action.openWorkspaceSettings
    workbench.action.openSettingsJson

*/

// src\vs\workbench\services\preferences\browser\preferencesService.ts


// src\main.ts
// not used in the web version

// src\vs\platform\environment\node\userDataPath.ts
function getUserDataPath() {
    return doGetUserDataPath()
}
function doGetUserDataPath() {
    // return 'C:\\Users\\<username>\\AppData\\Roaming\\Code'
    return 'C:/Users/<username>/AppData/Roaming/Code'
}

// src\vs\platform\environment\common\environmentService.ts
class AbstractNativeEnvironmentService {
    get userDataPath() {
        return this.paths.userDataDir
    }
    constructor(_args, paths) {
        this.paths = paths
    }
}

// src\vs\platform\environment\node\environmentService.ts
class NativeEnvironmentService extends AbstractNativeEnvironmentService {
    constructor() {     
        super(undefined, {
            userDataDir: getUserDataPath()
        })
    }
}

// src\vs\platform\environment\electron-main\environmentMainService.ts
class EnvironmentMainService extends NativeEnvironmentService {
}

// src\vs\code\electron-main\main.ts
class CodeMain {
    createServices() {
        this.environmentMainService = new EnvironmentMainService
    }
}

const codeMain = new CodeMain()
codeMain.createServices()
console.log(codeMain.environmentMainService.userDataPath)
