/*
    Inspired by
    src\vs\workbench\browser\parts\sidebar\sidebarPart.ts
*/
function test1() {
    const value = that.configurationService.getValue(LayoutSettings.ACTIVITY_BAR_LOCATION) === ActivityBarPosition.HIDDEN ? that.getRememberedActivityBarVisiblePosition() : ActivityBarPosition.HIDDEN;
}

function test() {
    let value
    const location = that.configurationService.getValue(LayoutSettings.ACTIVITY_BAR_LOCATION)
    if (location === ActivityBarPosition.HIDDEN) {
        value = that.getRememberedActivityBarVisiblePosition()
    } else {
        value = ActivityBarPosition.HIDDEN
    }
}

