/*

monaco-scrollable-element 

*/

// src\vs\base\browser\mouseEvent.ts
class StandardWheelEvent {
    constructor(e) {

    }
}

// src\vs\base\common\scrollable.ts
class Scrollable {

}

// src\vs\base\browser\ui\scrollbar\scrollableElement.ts
class AbstractScrollableElement {
    constructor(element, options, scrollable) {
        this._scrollable = scrollable
    }
    _setListeningToMouseWheel() {
        const onMouseWheel = (browserEvent) => {
            this._onMouseWheel(new StandardWheelEvent(browserEvent))
        }
        this._listenOnDomNode.addEventListener('wheel', onMouseWheel)
    }
    _onMouseWheel(e) {

    }
}


