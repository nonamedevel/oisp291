/*


caller --> callee


BaseWindow
    NativeWindow


NativeWindow.constructor                                    src\vs\workbench\electron-browser\window.ts
    NativeWindow.registerListeners                          src\vs\workbench\electron-browser\window.ts
        NativeWindow.createWindowZoomStatusEntry            src\vs\workbench\electron-browser\window.ts
            NativeWindow.updateWindowZoomStatusEntry        src\vs\workbench\electron-browser\window.ts
                ZoomStatusEntry.updateZoomEntry             src\vs\workbench\electron-browser\window.ts
                    ZoomStatusEntry.updateZoomLevelLabel    src\vs\workbench\electron-browser\window.ts
                        'Zoom Level'



                        

*/





