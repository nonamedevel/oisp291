// src\vs\editor\common\model\pieceTreeTextBuffer\rbTreeBase.ts
class TreeNode { // i4e

}
const SENTINEL = new TreeNode()

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeBase.ts
class Piece {

}

// src\vs\editor\common\model\pieceTreeTextBuffer\pieceTreeBase.ts
class PieceTreeBase { // jKi
    create() {
        this.root = SENTINEL
    }
}

// entry point
function test() {
    const pieceTreeBase = new PieceTreeBase()
    pieceTreeBase.create()
}
test()
