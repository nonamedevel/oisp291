/*

Disposable                  src\vs\base\common\lifecycle.ts
  Pane                      src\vs\base\browser\ui\splitview\paneview.ts
    ViewPane                src\vs\workbench\browser\parts\views\viewPane.ts
      TreeViewPane          src\vs\workbench\browser\parts\views\treeView.ts
  AbstractTreeView          src\vs\workbench\browser\parts\views\treeView.ts
    TreeView
  TreeRenderer              src\vs\workbench\browser\parts\views\treeView.ts


*/

class AbstractTreeView {
  
}

class TreeView extends AbstractTreeView {
	activate() {
		if (!this.activated) {
			this.createTree();
			this.activated = true;
		}
	}
}

const treeView = new TreeView()