/*

Disposable                      src\vs\base\common\lifecycle.ts
    Pane                        src\vs\base\browser\ui\splitview\paneview.ts
        ViewPane                src\vs\workbench\browser\parts\views\viewPane.ts
            TreeViewPane        src\vs\workbench\browser\parts\views\treeView.ts
    AbstractTreeView            src\vs\workbench\browser\parts\views\treeView.ts
        TreeView
    TreeRenderer                src\vs\workbench\browser\parts\views\treeView.ts


*/


// src\vs\workbench\common\views.ts
const TreeItemCollapsibleState = {
    None: 0,
    Collapsed: 1,
    Expanded: 2,
}

// src\vs\workbench\browser\parts\views\treeView.ts
class Root {
    label = { label: 'root' };
    handle = '0';
    parentHandle = undefined;
    collapsibleState = TreeItemCollapsibleState.Expanded;
    children = undefined;
}

class TreeViewPane {
    constructor() {
        this.treeView = new TreeView()
        this.treeView.dataProvider = {
            getChildren: getChildrenOfItem,
            getChildrenBatch: async (elements) => {
                if (elements && elements.length > largestBatchSize) {
                    largestBatchSize = elements.length;
                }
                if (elements) {
                    return Array(elements.length).fill([]);
                } else {
                    return [(await getChildrenOfItem()) ?? []];
                }
            }
        }
        this.updateTreeVisibility()
    }
	updateTreeVisibility() {
        // debugger
		this.treeView.setVisibility(true)
		// this.treeView.setVisibility(this.isBodyVisible())
	}
}

class AbstractTreeView {
    isVisible = false
    constructor() {
        this._dataProvider = null
        this.root = new Root()
    }
    get dataProvider() {
        return this._dataProvider
    }
    set dataProvider(dataProvider) {
        if (dataProvider) {
            if (this.isVisible) {
                this.activate();
            }
            const self = this;
            this._dataProvider = new class {

            }
        }
    }
    /*
        TODO: investigate initialize(), create()
    */
    setVisibility(isVisible) {
        this.isVisible = isVisible
    }
}

class TreeView extends AbstractTreeView {
    activate() {
        console.log(333)
        if (!this.activated) {
            this.createTree();
            this.activated = true;
        }
    }
}

const getChildrenOfItem = async (element) => {
    if (element) {
        return undefined;
    } else {
        const rootChildren = [];
        for (let i = 0; i < 100; i++) {
            rootChildren.push({
                handle: `item_${i}`,
                collapsibleState: TreeItemCollapsibleState.Expanded
            });
        }
        return rootChildren;
    }
};

// entry point
const treeViewPane = new TreeViewPane()
