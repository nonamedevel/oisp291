class App {
    constructor(opts) {
        if(opts.value !== undefined) {
            this.defaultValue = opts.value
        } else {
            this.defaultValue = 0
        }
        this.container = document.querySelector('.container')
        for (let i = 0; i < 16; i++) {
            const cell = document.createElement('div')
            cell.classList.add('cell')
            this.container.append(cell)
            this.setUint8(i, this.defaultValue)
        }
    }
    setUint8(index, value) {
        if(index >= 16){
            console.log('error')
            return
        }
        const cell = this.container.children[index]
        cell.textContent = value.toString(16).padStart(2, '0')
    }
    setUint16(index, value) {
        if(index >= 16 || index % 2 !== 0){
            console.log('error')
            return
        }
        let cell = this.container.children[index]
        const str = value.toString(16).padStart(4, '0')
        cell.textContent = str.slice(0,2)
        cell = this.container.children[index+1]
        cell.textContent = str.slice(2,4)
    }
    setUint32(index, value) {
        if(index >= 16 || index % 4 !== 0){
            console.log('error')
            return
        }
        let cell = this.container.children[index]
        const str = value.toString(16).padStart(8, '0')
        cell.textContent = str.slice(0,2)
        cell = this.container.children[index+1]
        cell.textContent = str.slice(2,4)
        cell = this.container.children[index+2]
        cell.textContent = str.slice(4,6)
        cell = this.container.children[index+3]
        cell.textContent = str.slice(6,8)
    }
}

const app = new App({
    // value : 0xff
})

// app.setUint8(8, 255)
/*
    Before:
    00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 
    After:
    00 00 00 00 00 00 00 00 ea 60 00 00 00 00 00 00 
*/
// app.setUint16(8, 60000)
app.setUint16(16, 0)
// app.setUint32(12,0xffffffff)

