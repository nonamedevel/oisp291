/*************** main.js ***************/
const container = document.querySelector('.container')

/*************** script1.js ***************/
const item1 = document.createElement('div')
item1.textContent = 'Item 1'
container.append(item1)

/*************** script2.js ***************/
const item2 = document.createElement('div')
item2.textContent = 'Item 2'
container.append(item2)

/*************** script3.js ***************/
const item3 = document.createElement('div')
item3.textContent = 'Item 3'
container.append(item3)