const fs = require('fs')

function mergeFiles() {
    let str = ''
    for (const fileName of fileNames) {
        try {
            const data = fs.readFileSync(srcPath + fileName, 'utf8')
            str += `/*************** ${fileName} ***************/\n${data}\n\n`
        } catch(err){
            console.log(err)
        }
    }
    str = str.slice(0, -2)
    const pathToFile = outPath + 'script.js'
    try {
        fs.writeFileSync(pathToFile, str)
    } catch(err) {
        console.log(err)
    }
}

function replacePlaceholders(arr) {
    const templatePath = srcPath + 'template.html'
    let data = fs.readFileSync(templatePath, 'utf8')
    for (const [searchValue, replaceValue] of arr) {
        data = data.replace(searchValue, replaceValue)
    }
    fs.writeFileSync(outPath + 'index.html', data)
}

const fileNames = [
    'main.js',
    'script1.js',
    // 'script2.js',
    'script3.js',
]
const srcPath = 'C:/oisp291/webpack_clone/src/'
const outPath = 'C:/oisp291/webpack_clone/out/'

mergeFiles()
replacePlaceholders([
    ['<script_placeholder>', '<script src="script.js"></script>'],
    ['<style_placeholder>', '<link rel="stylesheet" href="style.css">'],
])
