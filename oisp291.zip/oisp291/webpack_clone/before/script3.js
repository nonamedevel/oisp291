const item3 = document.createElement('div')
item3.textContent = 'Item 3'
container.append(item3)