const item1 = document.createElement('div')
item1.textContent = 'Item 1'
container.append(item1)