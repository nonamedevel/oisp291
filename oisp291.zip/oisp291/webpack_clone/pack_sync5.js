const fs = require('fs')

class SimplePack {
    static scriptPlaceholder = '<script_placeholder>'
    static stylePlaceholder = '<style_placeholder>'
    constructor(opts) {
        this.srcPath = opts.srcPath
        this.outPath = opts.outPath
        const jsFiles = []
        const cssFiles = []
        for (const item of opts.files) {
            const arr = item.split('.')
            if (arr.length > 1) {
                const fileExtension = arr[arr.length - 1]
                if (fileExtension === 'js') {
                    jsFiles.push(item)
                } else if (fileExtension === 'css') {
                    cssFiles.push(item)
                } else {
                    throw new Error('Only .js and .css files are supported')
                }
            } else {
                jsFiles.push(item + '.js')
                cssFiles.push(item + '.css')
            }
        }
        console.log(jsFiles)
        console.log(cssFiles)

        if (jsFiles.length > 0) {
            this.mergeFiles(jsFiles, 'script.js')
            this.replacePlaceholders(
                SimplePack.scriptPlaceholder,
                '<script src="script.js"></script>'
            )
        } else {
            this.replacePlaceholders(
                SimplePack.scriptPlaceholder,
                ''
            )
        }
        if (cssFiles.length > 0) {
            this.mergeFiles(cssFiles, 'style.css')
            this.replacePlaceholders(
                SimplePack.stylePlaceholder,
                '<link rel="stylesheet" href="style.css">'
            )
        } else {
            this.replacePlaceholders(
                SimplePack.stylePlaceholder,
                ''
            )
        }
    }
    mergeFiles(srcFiles, outFile) {
        let str = ''
        for (const fileName of srcFiles) {
            try {
                str += `/*************** ${fileName} ***************/\n`
                const data = fs.readFileSync(this.srcPath + fileName, 'utf8')
                str += `${data}\n\n`
            } catch(err){
                console.log(err)
            }
        }
        str = str.slice(0, -2)
        const pathToFile = this.outPath + outFile
        try {
            fs.writeFileSync(pathToFile, str)
        } catch(err) {
            console.log(err)
        }
    }
    replacePlaceholders(searchValue, replaceValue) {
        try {
            let templatePath
            if (!this.hasChanges) {
                templatePath = this.srcPath + 'template.html'
                this.hasChanges = true
            } else {
                templatePath = this.outPath + 'index.html'
            }            
            let data = fs.readFileSync(templatePath, 'utf8')
            data = data.replace(searchValue, replaceValue)
            fs.writeFileSync(this.outPath + 'index.html', data)
        } catch(err) {
            console.log(err)
        }
    }
}

const simplePack = new SimplePack({
    srcPath: 'C:/oisp291/webpack_clone/src2/',
    outPath: 'C:/oisp291/webpack_clone/out/',
    files: [
        'main.js', 
        'Widget1',
        'Widget2',
        'Widget3',
        // 'Widget1.js',
        // 'Widget1.css',
        // 'Widget2.js',
        // 'Widget2.css',
        // 'Widget3.js',
        // 'Widget3.css',
    ],
})