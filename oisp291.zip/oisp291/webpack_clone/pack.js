const fs = require('fs')

const fileNames = [
    'main.js',
    'script1.js',
    'script2.js',
    'script3.js',
]
const dirPath = 'C:/oisp291/webpack_clone/before/'
let str = ''
let counter = 0
for (const fileName of fileNames) {
    fs.readFile(dirPath + fileName, 'utf8', function(err, data) {
        str += `\n\n/*************** ${fileName} ***************/\n${data}`
        counter++
        if (counter < fileNames.length) {
            return
        }
        console.log(str)
    })
}