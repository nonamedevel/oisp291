const item2 = document.createElement('div')
item2.textContent = 'Item 2'
container.append(item2)