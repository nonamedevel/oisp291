const fs = require('fs')

class SimplePack {
    static scriptPlaceholder = '<script_placeholder>'
    static stylePlaceholder = '<style_placeholder>'
    constructor(opts) {
        this.srcPath = opts.srcPath
        this.outPath = opts.outPath

        if (opts.jsFiles !== undefined) {
            this.mergeFiles(opts.jsFiles, 'script.js')
            this.replacePlaceholders(
                SimplePack.scriptPlaceholder,
                '<script src="script.js"></script>'
            )
        } else {
            this.replacePlaceholders(
                SimplePack.scriptPlaceholder,
                ''
            )
        }
        if (opts.cssFiles !== undefined) {
            this.mergeFiles(opts.cssFiles, 'style.css')
            this.replacePlaceholders(
                SimplePack.stylePlaceholder,
                '<link rel="stylesheet" href="style.css">'
            )
        } else {
            this.replacePlaceholders(
                SimplePack.stylePlaceholder,
                ''
            )
        }
    }
    mergeFiles(srcFiles, outFile) {
        let str = ''
        for (const fileName of srcFiles) {
            try {
                str += `/*************** ${fileName} ***************/\n`
                const data = fs.readFileSync(this.srcPath + fileName, 'utf8')
                str += `${data}\n\n`
            } catch(err){
                console.log(err)
            }
        }
        str = str.slice(0, -2)
        const pathToFile = this.outPath + outFile
        try {
            fs.writeFileSync(pathToFile, str)
        } catch(err) {
            console.log(err)
        }
    }
    replacePlaceholders(searchValue, replaceValue) {
        const templatePath = this.srcPath + 'template.html'
        let data = fs.readFileSync(templatePath, 'utf8')
        data = data.replace(searchValue, replaceValue)
        fs.writeFileSync(this.outPath + 'index.html', data)
    }
}

const simplePack = new SimplePack({
    srcPath: 'C:/oisp291/webpack_clone/src/',
    outPath: 'C:/oisp291/webpack_clone/out/',
    jsFiles: [
        'main.js',
        'script1.js',
        'script2.js',
        'script3.js',
    ],
    // cssFiles: [
    //     'style1.css',
    //     'style2.css',
    //     'style3.css',
    // ],
})