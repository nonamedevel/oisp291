const item2 = document.createElement('div')
item2.textContent = 'Item 2'
item2.classList.add('widget2')
container.append(item2)