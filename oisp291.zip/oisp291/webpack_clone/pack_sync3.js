/*
    Homework:
    (1) Convert this code to a class
    (2) Add config.json and move the names of files and other info into that file
*/
const fs = require('fs')

class SimplePack {
    constructor() {
        this.srcPath = 'C:/oisp291/webpack_clone/src/'
        this.outPath = 'C:/oisp291/webpack_clone/out/'
        
        this.mergeFiles([
            'main.js',
            'script1.js',
            'script2.js',
            'script3.js',
        ], 'script.js')
        this.mergeFiles([
            'style1.css',
            'style2.css',
            'style3.css',
        ], 'style.css')
        this.replacePlaceholders([
            ['<script_placeholder>', '<script src="script.js"></script>'],
            ['<style_placeholder>', '<link rel="stylesheet" href="style.css">'],
        ])
    }
    mergeFiles(srcFiles, outFile) {
        let str = ''
        for (const fileName of srcFiles) {
            try {
                const data = fs.readFileSync(this.srcPath + fileName, 'utf8')
                str += `/*************** ${fileName} ***************/\n${data}\n\n`
            } catch(err){
                console.log(err)
            }
        }
        str = str.slice(0, -2)
        const pathToFile = this.outPath + outFile
        try {
            fs.writeFileSync(pathToFile, str)
        } catch(err) {
            console.log(err)
        }
    }
    replacePlaceholders(arr) {
        const templatePath = this.srcPath + 'template.html'
        let data = fs.readFileSync(templatePath, 'utf8')
        for (const [searchValue, replaceValue] of arr) {
            data = data.replace(searchValue, replaceValue)
        }
        fs.writeFileSync(this.outPath + 'index.html', data)
    }
}

const simplePack = new SimplePack()
