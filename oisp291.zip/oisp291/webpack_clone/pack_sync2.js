const fs = require('fs')

function mergeFiles(srcFiles, outFile) {
    let str = ''
    for (const fileName of srcFiles) {
        try {
            const data = fs.readFileSync(srcPath + fileName, 'utf8')
            str += `/*************** ${fileName} ***************/\n${data}\n\n`
        } catch(err){
            console.log(err)
        }
    }
    str = str.slice(0, -2)
    const pathToFile = outPath + outFile
    try {
        fs.writeFileSync(pathToFile, str)
    } catch(err) {
        console.log(err)
    }
}

function replacePlaceholders(arr) {
    const templatePath = srcPath + 'template.html'
    let data = fs.readFileSync(templatePath, 'utf8')
    for (const [searchValue, replaceValue] of arr) {
        data = data.replace(searchValue, replaceValue)
    }
    fs.writeFileSync(outPath + 'index.html', data)
}

const srcPath = 'C:/oisp291/webpack_clone/src/'
const outPath = 'C:/oisp291/webpack_clone/out/'

mergeFiles([
    'main.js',
    'script1.js',
    'script2.js',
    'script3.js',
], 'script.js')
mergeFiles([
    'style1.css',
    'style2.css',
    'style3.css',
], 'style.css')
replacePlaceholders([
    ['<script_placeholder>', '<script src="script.js"></script>'],
    ['<style_placeholder>', '<link rel="stylesheet" href="style.css">'],
])
