const {Server} = require('./server.js')

const server = new Server(4000)
// server.addRoute('/', function (res) {
//     server.readFile(res, 'C:/oisp291/http_server/static/index.html')
// })
// server.addRoute('/about', function (res) {
//     server.readFile(res, 'C:/oisp291/http_server/static/about.html')
// })
// server.addRoute('/contacts', function (res) {
//     server.readFile(res, 'C:/oisp291/http_server/static/contacts.html')
// })

server.addStaticRoute('/', 'C:/oisp291/http_server/static/index.html')
server.addStaticRoute('/about', 'C:/oisp291/http_server/static/about.html')
server.addStaticRoute('/contacts', 'C:/oisp291/http_server/static/contacts.html')
