const {Server} = require('./server.js')

const server = new Server({
    port: 4000,
    staticFolder: 'C:/oisp291/http_server/static/',
    unwantedRoutes: [
        '/.well-known/appspecific/com.chrome.devtools.json',
        '/favicon.ico',
    ],
    notFoundStr: '<h1>404 Not found</h1>',
})
// server.addRoute('/', function (res) {
//     server.readFile(res, 'C:/oisp291/http_server/static/index.html')
// })
// server.addRoute('/about', function (res) {
//     server.readFile(res, 'C:/oisp291/http_server/static/about.html')
// })
// server.addRoute('/contacts', function (res) {
//     server.readFile(res, 'C:/oisp291/http_server/static/contacts.html')
// })

server.addStaticRoute('/', 'index.html')
server.addStaticRoute('/about', 'about.html')
server.addStaticRoute('/contacts', 'contacts.html')
server.addStaticRoute('/signup', 'signup.html')
