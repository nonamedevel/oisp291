const {Server} = require('./server.js')

const server = new Server(5000)
server.addRoute('/', function (res) {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    })
    res.end('<h1 style="color: red">Single page application</h1>')
})
