const {Server} = require('./server.js')

const server = new Server(4000)
server.addRoute('/', function (res) {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    })
    res.end('<h1 style="color: red">Main page</h1>')
})
server.addRoute('/about', function (res) {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    })
    res.end('<h1 style="color: green">About page</h1>')
})
server.addRoute('/contacts', function (res) {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    })
    res.end('<h1 style="color: blue">Contacts page</h1>')
})
