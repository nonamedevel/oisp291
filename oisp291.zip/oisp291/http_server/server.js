const http = require('http')
const fs = require('fs')

class Server {
    constructor(opts) {
        this.staticFolder = opts.staticFolder
        const unwantedRoutes = [
            '/.well-known/appspecific/com.chrome.devtools.json',
            '/favicon.ico',
        ]
        this.routes = {}
        const server = http.createServer((req, res) => {
            if (!unwantedRoutes.includes(req.url)) {
                console.log(req.url)
            }
            if (this.routes[req.url]) {
                this.routes[req.url](res)
            } else {
                res.writeHead(404, {
                    'Content-Type': 'text/html'
                })
                res.end('<h1>404 Not found</h1>')
            }
        })
        server.listen(opts.port)
    }
    addRoute(route, callback) {
        this.routes[route] = callback
    }
    addStaticRoute(route, filePath) {
        this.routes[route] = (res) => {
            this.readFile(res, `${this.staticFolder}/${filePath}`)
        }
    }
    readFile(res, path){
        fs.readFile(path, 'utf8', function(err, data) {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    }
}

module.exports = {
    Server,
}