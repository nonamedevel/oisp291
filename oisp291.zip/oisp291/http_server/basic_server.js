const http = require('http')

function test1() {
    const server = http.createServer(function(req, res) {
        res.end('hello there!')
    })
    server.listen(4000)
}

function test2() {
    const unwantedRoutes = [
        '/.well-known/appspecific/com.chrome.devtools.json',
        '/favicon.ico',
    ]
    const server = http.createServer(function(req, res) {
        if (!unwantedRoutes.includes(req.url)) {
            console.log(req.url)
        }
        res.end('hello there!')
    })
    server.listen(4000)
}

function test3() {
    const unwantedRoutes = [
        '/.well-known/appspecific/com.chrome.devtools.json',
        '/favicon.ico',
    ]
    const server = http.createServer(function(req, res) {
        if (!unwantedRoutes.includes(req.url)) {
            console.log(req.url)
        }
        if (req.url === '/') {
            res.end('<h1 style="color: red">Main page</h1>')
        } else if (req.url === '/about') {
            res.end('<h1 style="color: green">About page</h1>')
        } else if (req.url === '/contacts') {
            res.end('<h1 style="color: blue">Contacts page</h1>')
        } else {
            res.end('<h1>404 Not found</h1>')
        }
    })
    server.listen(4000)
}

function test4() {
    const unwantedRoutes = [
        '/.well-known/appspecific/com.chrome.devtools.json',
        '/favicon.ico',
    ]
    const server = http.createServer(function(req, res) {
        if (!unwantedRoutes.includes(req.url)) {
            console.log(req.url)
        }
        if (req.url === '/') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1 style="color: red">Main page</h1>')
        } else if (req.url === '/about') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1 style="color: green">About page</h1>')
        } else if (req.url === '/contacts') {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1 style="color: blue">Contacts page</h1>')
        } else {
            res.writeHead(404, {
                'Content-Type': 'text/html'
            })
            res.end('<h1>404 Not found</h1>')
        }
    })
    server.listen(4000)
}

function test() {
    const unwantedRoutes = [
        '/.well-known/appspecific/com.chrome.devtools.json',
        '/favicon.ico',
    ]
    const routes = {
        '/': function(res) {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1 style="color: red">Main page</h1>')
        },
        '/about': function(res) {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1 style="color: green">About page</h1>')
        },
        '/contacts': function(res) {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end('<h1 style="color: blue">Contacts page</h1>')
        }
    }
    const server = http.createServer(function(req, res) {
        if (!unwantedRoutes.includes(req.url)) {
            console.log(req.url)
        }
        if (routes[req.url]) {
            routes[req.url](res)
        } else {
            res.writeHead(404, {
                'Content-Type': 'text/html'
            })
            res.end('<h1>404 Not found</h1>')
        }
    })
    server.listen(4000)
}

test()
