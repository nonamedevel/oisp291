const http = require('http')

const server = http.createServer(function(req, res) {
    res.end('hello there!')
})

server.listen(4000)