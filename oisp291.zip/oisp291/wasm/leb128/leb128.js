/*
    624485      0x09 0x87 0x65
    00001001 10000111 01100101

    000 0100110 0001110 1100101

    229, 142, 38,
    11100101    10001110    00100110
*/
function encodeULEB128(value) {
    const bytes = [];
    do {
        let byte = value & 0x7F;
        value >>>= 7;
        if (value !== 0) {
            byte |= 0x80;
        }
        bytes.push(byte);
    } while (value !== 0);
    return Uint8Array.from(bytes);
}

function decodeULEB128(bytes) {
    let result = 0;
    let shift = 0;
    for (const byte of bytes) {
        result |= (byte & 0x7F) << shift;
        if ((byte & 0x80) === 0) break;
        shift += 7;
    }
    return result;
}

function encodeSLEB128(value) {
    const bytes = [];
    let more = true;
    const isNegative = value < 0;

    while (more) {
        let byte = value & 0x7F;
        value >>= 7;

        const signBit = (byte & 0x40) !== 0;
        if ((value === 0 && !signBit) || (value === -1 && signBit)) {
            more = false;
        } else {
            byte |= 0x80;
        }
        bytes.push(byte);
    }
    return Uint8Array.from(bytes);
}

function decodeSLEB128(bytes) {
    let result = 0;
    let shift = 0;
    let byte;
    for (let i = 0; i < bytes.length; i++) {
        byte = bytes[i];
        result |= (byte & 0x7F) << shift;
        shift += 7;
        if ((byte & 0x80) === 0) break;
    }

    // Sign extend if needed
    if (shift < 32 && (byte & 0x40)) {
        result |= (~0 << shift);
    }
    return result;
}

function test() {
    debugger
    const uVal = 624485; // Example unsigned
    const uEnc = encodeULEB128(uVal);
    console.log("ULEB128 Encoded:", uEnc);
    console.log("ULEB128 Decoded:", decodeULEB128(uEnc));
    
    const sVal = -123456; // Example signed
    const sEnc = encodeSLEB128(sVal);
    console.log("SLEB128 Encoded:", sEnc);
    console.log("SLEB128 Decoded:", decodeSLEB128(sEnc));
}

test()
