const container = document.querySelector('.container')
const button = document.querySelector('.addNname')
const nameInput = document.querySelector('.nameInput')
button.addEventListener('click', test)
function test() {

    const str = nameInput.value
    const strLength = str.length
    const arr = []
    for (const ch of str) {
        arr.push(ch.charCodeAt(0))
    }

    const bytes = new Uint8Array([
        0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
        0x01, 0x05, 0x01, // type
        0x60, 0x00, 0x01, 0x7f,
        0x03, 0x02, 0x01, 0x00, // function
        0x07, 0x07, 0x01, // export
        0x03, 0x61, 0x62, 0x63, 0x00, 0x00,
        0x0a, 0x06, 0x01, // code
        0x04, 0x00,
        0x41, 0x11,
        0x0b,
    ])

    const prefix = bytes.slice(0, 20)
    const end = bytes.slice(26)

    const newBytes = new Uint8Array([
        ...prefix, 
        strLength + 4, 
        0x01, 
        strLength, 
        ...arr, 
        ...end
    ])
    console.log(newBytes, 'newarray')
    WebAssembly.instantiate(newBytes).then(({ instance }) => {
        const result = instance.exports[str]()
        console.log(result)
    })
}

function test1() {
    // const arr = [0x65, 0x78, 0x61, 0x6d, 0x70, 0x6c, 0x65]
    const arr = [0x61, 0x62, 0x63]
    let str = ''
    for (const byte of arr) {
        str += String.fromCharCode(byte)
    }
    console.log(str)
}

function test1() {
    const str = 'example'
    const arr = []
    for (const ch of str) {
        arr.push('0x' + ch.charCodeAt(0).toString(16).padStart(2, '0'))
    }
    console.log("'" + arr.join("', '") + "'")
}

function test1() {
    const arr1 = [5, 10, 15, 20, 25, 30, 35]
    const arr2 = [5, 10, 333, 444, 30, 35]
    const prefix = arr1.slice(0, 4)
    console.log(prefix)
    const suffix = arr1.slice(5)
    console.log(suffix)
    const result = [
        ...prefix,
        333, 444,
        ...suffix,
    ]
    console.log(result)
}

test()