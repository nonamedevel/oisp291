/*
    atob('str').split('').map(ch => '0x' + ch.charCodeAt(0).toString(16).padStart(2, '0'))

    5.5.17 Modules          p.207
    5.5.2 Sections          p.203
    5.3.1 Number Types      p.184
*/
function test() {
    const bytes = new Uint8Array([
        '0x00', '0x61', '0x73', '0x6d', '0x01', '0x00', '0x00', '0x00', 
        '0x01', '0x07', '0x01', // type
            '0x60', '0x02', '0x7f', '0x7f', '0x01', '0x7f', 
        '0x03', '0x02', '0x01', '0x00', // function
        '0x07', '0x0b', '0x01', // export
            '0x07', '0x65', '0x78', '0x61', '0x6d', '0x70', '0x6c', '0x65', '0x00', '0x00', 
        '0x0a', '0x09', '0x01', // code
            '0x07', '0x00', 
                '0x20', '0x00', 
                '0x20', '0x01', 
                '0x6a',
            '0x0b',
    ])
    WebAssembly.instantiate(bytes).then(({instance}) => {
        const result = instance.exports.example(10, 15)
        console.log(result)
    })
}

function test1() {
    const arr = ['0x61', '0x64', '0x64', '0x54', '0x77', '0x6f']
}

function test1() {
    const str = 'example'
    const arr = []
    for (const ch of str) {
        arr.push('0x' + ch.charCodeAt(0).toString(16).padStart(2, '0'))
    }
    console.log("'" + arr.join("', '") + "'")
}

test()
