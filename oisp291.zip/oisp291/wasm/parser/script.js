/*
    (1) Проверить преамбулу (binary magic)
    (2) Извлечь информацию о секциях
    Алгоритм:
        Шаг 1: Прочитать байт (id секции)
        Шаг 2: Прочитать следующий байт (размер секции в байтах)
        Шаг 3: Скопировать байты секции в объект
        Шаг 4: Перейти к следующей секции (шаг 1)
*/
const arr = [
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
    0x01, 0x05, 0x01, // type
        0x60, 0x00, 0x01, 0x7f,
    0x03, 0x02, 0x01, 0x00, // function
    0x07, 0x07, 0x01, // export
        0x03, 0x61, 0x62, 0x63, 0x00, 0x00,
    0x0a, 0x06, 0x01, // code
        0x04, 0x00,
            0x41, 0x11,
        0x0b,
]
const preamble = [0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00]
function parse(arr){
    let pos = 0
    for ( ; pos<8; pos++) {
        if (arr[pos] !== preamble[pos]) {
            return
        }
    }
    const result = {}
    while(pos < arr.length){
        const sectionId = arr[pos]
        const sectionSize = arr[pos+1]
        console.log(sectionId, sectionSize)
        pos += 2
        if (sectionId === 1) {
            result.type = arr.slice(pos, pos+sectionSize)
        } else if (sectionId === 3) {
            result.function = arr.slice(pos, pos+sectionSize)
        } else if (sectionId === 7) {
            result.export = arr.slice(pos, pos+sectionSize)
        } else if (sectionId === 10) {
            result.code = arr.slice(pos, pos+sectionSize)
        } else {
            return
        }
        pos += sectionSize
    }
    console.log(result)
}
// parse(arr)

const obj = {
    type: [ 1, 96, 0, 1, 127 ],
    function: [ 1, 0 ],
    export: [ 1, 3, 97, 98, 99, 0,  0 ],
    code: [ 1, 4, 0, 65, 17, 11 ]
}

function build(obj) {
    const result = [...preamble]
    //console.log(Object.entries(obj).length)
    for(const item of Object.values(obj)) {
        result.push(...item)
    }
    return result
}
const arr2 = build(obj)

function compareArr(arr, arr2) {
    for(let i = 0; i < arr.length; i++) {
        if(arr[i] !== arr2[i]) {
            console.log(i,arr[i],arr2[i])
            return false
        }
    }
    return true
}
console.log(compareArr(arr, arr2))