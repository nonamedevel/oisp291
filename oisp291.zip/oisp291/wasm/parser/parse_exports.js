const bytes = [
    0x07, 0x13, 0x03, 
        0x02, 0x66, 0x66, 0x00, 0x00, 
        0x03, 0x66, 0x66, 0x66, 0x00, 0x01, 
        0x04, 0x66, 0x66, 0x66, 0x66, 0x00, 0x02,
]
const bytes2 = [
    0x07, 0x13, 0x03, 
        0x04, 0x66, 0x66, 0x66, 0x66, 0x00, 0x02, 
        0x02, 0x66, 0x66, 0x00, 0x00, 
        0x03, 0x66, 0x66, 0x66, 0x00, 0x01,
]

const expectedResult = {
    sectionName: 'export',
    data: [
        {name: 'ff', type: 'func', idx: 0},
        {name: 'fff', type: 'func', idx: 1},
        {name: 'ffff', type: 'func', idx: 2},
    ]
}

function parseExports(bytes) {
    if(bytes[0] !== 7) {
        return
    }
    const result = {
        sectionName: 'export',
        data: []
    }
    let pos = 3
    for(let i = 0; i < bytes[2]; i++) {
        console.log(bytes.slice(pos, bytes[pos]+pos))
    }
}

const result = parseExports(bytes)
console.log(result)
