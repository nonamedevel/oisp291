/*
    0x7C ⇒ f64
    0x7D ⇒ f32
    0x7E ⇒ i64
    0x7F ⇒ i32
*/

const example1 = [
    0x01, 0x10, 0x03, 
        0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7f, 
        0x60, 0x00, 0x00,
        0x60, 0x00, 0x03, 0x7e, 0x7e, 0x7e,
]
const expected = {
    id: 1,
    size: 16,
    items: [
        {param: ['i32', 'i32'], result: ['i32']},
        {param: [], result: []},
        {param: [], result: ['i64', 'i64']},
    ]
}

function parseTypesSection(bytes) {
    outputMass = {}
    for (let i=0; i<bytes.length; i++){
        console.log(bytes[i])
        outputMass.id = bytes[0]
    }
}

const result = parseTypesSection(example1)
