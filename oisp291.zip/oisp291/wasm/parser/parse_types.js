/*
    0x7C ⇒ f64
    0x7D ⇒ f32
    0x7E ⇒ i64
    0x7F ⇒ i32
*/

const example1 = [
    0x01, 0x10, 0x03,
        0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7f,
        0x60, 0x00, 0x00,
        0x60, 0x00, 0x03, 0x7e, 0x7e, 0x7e,
]
const expected = {
    id: 1,
    size: 16,
    items: [
        { param: ['i32', 'i32'], result: ['i32'] },
        { param: [], result: [] },
        { param: [], result: ['i64', 'i64'] },
    ]
}

function parseTypesSection(bytes) {
    let pos = 0
    let dataType = {
        0x7C: "f64",
        0x7D: "f32",
        0x7E: "i64",
        0x7F: "i32"
    }

    const sectionObj = {}
    sectionObj.id = bytes[pos]
    pos++
    sectionObj.size = bytes[pos]
    pos++
    sectionObj.items = []
    const itemCount = bytes[pos]
    pos++
    for (let i = 0; i < itemCount; i++) {
        if (bytes[pos] !== 0x60) {
            return
        }
        pos++
        const obj = {
            param: [],
            result: []
        }
        sectionObj.items.push(obj)
        const paramUpperBound = pos+bytes[pos]+1
        pos++
        for(; pos < paramUpperBound; pos++){
            obj.param.push(dataType[bytes[pos]])
        }
        const resultUpperBound = pos+bytes[pos]+1
        pos++
        for(; pos < resultUpperBound; pos++){
            obj.result.push(dataType[bytes[pos]])
        }
    }
    return sectionObj
}

const result = parseTypesSection(example1)
console.log(result)