function test1() {
    const str1 = 'single quote'
    const str2 = "double quote"
    const str3 = `backtick (backquote)`
    console.log(str1)
    console.log(str2)
    console.log(str3)
}

function test1() {
    // const str = '"quote" значит "кавычка"'
    // const str = "'quote' значит 'кавычка'"
    // const str = "\"quote\" значит \"кавычка\""
    const str = '\'quote\' значит \'кавычка\''
    console.log(str)
}

/*
    Multiline string
    Многострочная строка
*/
function test1() {
    const str = `.ascii_table div {
        width: var(--cell-width);
        background-color: aqua;
        border-radius: 5px;
        text-align: center;
    }`
    console.log(str)
}

function test() {
    const borderRadius = 55
    const str = `.ascii_table div {
        width: var(--cell-width);
        background-color: aqua;
        border-radius: ${borderRadius}px;
        text-align: center;
    }`
    console.log(str)
}

test()