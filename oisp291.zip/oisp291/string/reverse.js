function test1() {
    class ReversString {
        constructor(string) {
            this.stringRevers = ""
            // for (let i = string.length - 1; i >= 0; i--) {
            //     this.stringRevers += string[i]
            // }
            for (let i = 0; i < string.length; i++){
                this.stringRevers += string[string.length - i - 1]
            }
            console.log(this.stringRevers)
        }
    }
    const str = new ReversString("Привет")
    const str1 = new ReversString(str.stringRevers)
}

function test1() {
    class ReversString {
        reverse (string) {
            this.stringRevers = ""
            for (let i = 0; i < string.length; i++){
                this.stringRevers += string[string.length - i - 1]
            }
            return this.stringRevers
        }
    }
    const str = new ReversString()
    const str1 = str.reverse("Привет")
    console.log(str1)
    const str2 = str.reverse(str1)
    console.log(str2)
}

function test1() {
    class ReversString {
        constructor (string){
            this.string = string
        }
        reverse () {
            let stringRevers = ""
            for (let i = 0; i < this.string.length; i++){
                stringRevers += this.string[this.string.length - i - 1]
            }
            this.string = stringRevers
            // return this
            return this.string
        }
        toString(){
            return this.string
        }
    }
    const str = new ReversString('Hello')
    // console.log(str.reverse().toString())  
    // console.log(str.reverse().toString())  
    console.log(str.reverse())  
    console.log(str.reverse()) 
}

function test() {
    class MyString {
        constructor(str) {
            this.strEnd = ''
            for (let ch of str) {
                this.strEnd = ch + this.strEnd
            }
            console.log(this.strEnd)
        }
    }
    let as = new MyString('Привет')
    as = new MyString(as.strEnd)
}
test()



/*
1+2=3  2+1=3

'пп'+'бб'='ппбб'
'бб'+'пп'='ббпп'
*/