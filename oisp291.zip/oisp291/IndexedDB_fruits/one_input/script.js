class FruitApp {
  constructor() {
    this.input = document.querySelector('input');
    this.message = document.querySelector('.message');
    this.addBtn = document.querySelector('.add_fruit');
    this.delBtn = document.querySelector('.delete_fruit');
    this.clearBtn = document.querySelector('.clear_button');
    this.list = document.querySelector('.fruit_list');
    this.db = null;

    this.addBtn.onclick = () => this.addFruit();
    this.delBtn.onclick = () => this.deleteFruit();
    this.clearBtn.onclick = () => this.clearAll();

    this.openDB();
  }

  showMessage(text, color = '#d32f2f') {
    this.message.textContent = text;
    this.message.style.color = color;
    setTimeout(() => (this.message.textContent = ''), 2000);
  }

  openDB() {
    const request = indexedDB.open('fruitsDB', 1);

    request.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('fruits')) {
        db.createObjectStore('fruits', { keyPath: 'name' });
      }
    };

    request.onsuccess = event => {
      this.db = event.target.result;
      this.showAll();
    };
  }

  addFruit() {
    const name = this.input.value.trim();
    if (!name) return this.showMessage('Введите фрукт');
    const tx = this.db.transaction('fruits', 'readwrite');
    const store = tx.objectStore('fruits');
    const req = store.add({ name });
    req.onsuccess = () => {
      this.input.value = '';
      this.showMessage('Добавлено!', '#388e3c');
      this.showAll();
    };
    req.onerror = () => this.showMessage('Такой фрукт уже есть');
  }

  deleteFruit() {
    const name = this.input.value.trim();
    if (!name) return this.showMessage('Введите фрукт для удаления');
    const tx = this.db.transaction('fruits', 'readwrite');
    const store = tx.objectStore('fruits');
    const req = store.delete(name);
    req.onsuccess = () => {
      this.input.value = '';
      this.showMessage('Удалено', '#5e35b1');
      this.showAll();
    };
  }

  clearAll() {
    const tx = this.db.transaction('fruits', 'readwrite');
    const store = tx.objectStore('fruits');
    const req = store.clear();
    req.onsuccess = () => {
      this.showMessage('Очищено', '#5e35b1');
      this.showAll();
    };
  }

  showAll() {
    const tx = this.db.transaction('fruits', 'readonly');
    const store = tx.objectStore('fruits');
    const req = store.getAll();
    req.onsuccess = () => {
      this.list.innerHTML = '';
      req.result.forEach(fruit => {
        const div = document.createElement('div');
        div.textContent = fruit.name;
        this.list.appendChild(div);
      });
    };
  }
}

new FruitApp();