class FruitApp {
  constructor() {
    this.input = document.querySelector('.text_input');
    this.priceInput = document.querySelector('.price_input');
    this.message = document.querySelector('.message');
    this.addBtn = document.querySelector('.add_fruit');
    this.delBtn = document.querySelector('.delete_fruit');
    this.clearBtn = document.querySelector('.clear_button');
    this.list = document.querySelector('.fruit_list');

    this.currentCurrency = 'rouble'
    this.currencyToggle = document.querySelector('.currency');
    this.db = null;

    this.currencyToggle.onclick = this.toggleCurrency.bind(this)
    this.addBtn.onclick = () => this.addFruit();
    this.delBtn.onclick = () => this.deleteFruit(this.input.value.trim());
    this.clearBtn.onclick = () => this.clearAll();

    this.openDB();
  }
  toggleCurrency(event) {
    if (event.target.tagName !== 'BUTTON') {
      return
    }
    if (event.target.classList.contains('rouble')) {
      this.currentCurrency = 'rouble'
    } else {
      this.currentCurrency = 'dollar'
    }
    document.querySelector('.selected').classList.remove('selected')
    event.target.classList.add('selected')
  }
  showMessage(text, color = '#d32f2f') {
    this.message.textContent = text;
    this.message.style.color = color;
    setTimeout(() => (this.message.textContent = ''), 2000);
  }

  openDB() {
    const request = indexedDB.open('fruitsDB', 1);

    request.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('fruits')) {
        db.createObjectStore('fruits', { keyPath: 'name' });
      }
    };

    request.onsuccess = event => {
      this.db = event.target.result;
      this.showAll();
    };
  }

  addFruit() {
    const name = this.input.value.trim();
    const price = this.priceInput.value.trim();
    if (!name) return this.showMessage('Введите фрукт');
    if (!price) return this.showMessage('Введите цену');
    const tx = this.db.transaction('fruits', 'readwrite');
    const store = tx.objectStore('fruits');
    const req = store.add({ name, price, currency: this.currentCurrency });
    req.onsuccess = () => {
      this.input.value = '';
      this.priceInput.value = '';
      this.showMessage('Добавлено!', '#388e3c');
      this.showAll();
    };
    req.onerror = () => this.showMessage('Такой фрукт уже есть');
  }

  deleteFruit(name) {
    if (!name) return this.showMessage('Введите фрукт для удаления');
    const tx = this.db.transaction('fruits', 'readwrite');
    const store = tx.objectStore('fruits');
    const req = store.delete(name);
    req.onsuccess = () => {
      this.input.value = '';
      this.showMessage('Удалено', '#5e35b1');
      this.showAll();
    };
  }

  clearAll() {
    const tx = this.db.transaction('fruits', 'readwrite');
    const store = tx.objectStore('fruits');
    const req = store.clear();
    req.onsuccess = () => {
      this.showMessage('Очищено', '#5e35b1');
      this.showAll();
    };
  }

  showAll() {
    const tx = this.db.transaction('fruits', 'readonly');
    const store = tx.objectStore('fruits');
    const req = store.getAll();
    req.onsuccess = () => {
      this.list.innerHTML = '';
      req.result.forEach(fruit => {
        const div = document.createElement('div');
        div.textContent = "[ " + fruit.name + " ] = " + fruit.price + ' ' + fruit.currency;
        const del_btn = document.createElement('button');
        del_btn.classList.add('deletebtn');
        del_btn.innerHTML = '🗑️';
        del_btn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.deleteFruit(fruit.name)
          div.remove();
        });
        div.appendChild(del_btn);
        this.list.appendChild(div);
      });
    };
  }
}

new FruitApp();