function test() {
    const date = new Date()
    // const date = Date()
    console.log(date)

    // console.log(date.getFullYear())
    // console.log(date.getMonth())
    // console.log(date.getDate())

    console.log(date.getHours())
    console.log(date.getMinutes())
    console.log(date.getSeconds())

    const hh = date.getHours()
    const mm = date.getMinutes()
    const ss = date.getSeconds()

    console.log(`${hh}:${mm}:${ss}`)
}

test()
