function test1() {
    setTimeout(function() {
        console.log(123)
    }, 2000)
    setTimeout(function() {
        console.log(456)
    }, 1000)
}

function test1() {
    setInterval(function() {
        console.log(123)
    }, 1000)
}

function test() {
    let counter = 0
    const intervalId = setInterval(function() {
        console.log(123)
        counter++
        if (counter < 3) {
            return
        }
        clearInterval(intervalId)
    }, 1000)
}

test()
