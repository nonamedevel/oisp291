
/*
    Variables with the same name
*/
function test1() {
    let index = 333
    function innerFunc() {
        // let index = 555
        console.log(index)
    }
    innerFunc()
}

function test() {
    let index1 = 333
    function innerFunc() {
        let index2 = 555
        console.log(index1)
        console.log(index2)
    }
    innerFunc()
}

test()
