const http = require('http')
const fs = require('fs')

const server = http.createServer(function(req, res) {
    if (req.url === '/') {
        fs.readFile('C:/oisp291/fetch/index.html', function(err, data) {
            res.writeHead(200, {
                'Content-Type': 'text/html'
            })
            res.end(data)
        })
    } else if (req.url === '/text_data') {
        res.writeHead(200, {
            'Content-Type': 'text/plain'
        })
        res.end('hello!!!')
    } else if (req.url === '/json_data') {
        res.writeHead(200, {
            'Content-Type': 'application/json'
        })
        res.end(JSON.stringify({num: 123}))
    } else {
        res.writeHead(404, {
            'Content-Type': 'text/html'
        })
        res.end(`<h1>404 Not found</h1>`)
    }
})

server.listen(4000)
