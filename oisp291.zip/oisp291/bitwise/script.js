function test1() {
    const minByte = 0b0000_0000 // 0
    const maxByte = 0b1111_1111 // 255
    let byte = 0b0000_1111
    console.log(byte)
    console.log((2 ** 3) + (2 ** 2) + (2 ** 1) + (2 ** 0))
}

function test1() {
    let byte = 0b0000_1111
    console.log(byte << 2)
    console.log((2 ** 5) + (2 ** 4) + (2 ** 3) + (2 ** 2))
}

function test1() {
    let byte1 = 0b0000_1111
    let byte2 = 0b1111_0000
    console.log(byte1 << 4)
    console.log(byte2)
}

function test1() {
    let byte1 = 0b0000_1111
    let byte2 = 0b1111_0000
    let byte3 = 0b1111_1111
    console.log(byte1 | byte2)
    console.log(byte3)
}

function test1() {
    let byte1 = 0b0000_1101
    let byte2 = 0b1001_1000
    let byte3 = 0b0000_1000
    console.log(byte1 & byte2)
    console.log(byte3)
}

function test() {
    function shiftLeft(byte, offset) {
        const result = []
        for(let i = offset; i < byte.length; i++) {
            result.push(byte[i])
        }
        for(let i = offset; i > 0; i--) {
            result.push(0)
        }
        return result
    }

    console.log(shiftLeft([0, 0, 0, 0, 1, 1, 1, 1], 0))
    console.log(shiftLeft([0, 0, 0, 0, 1, 1, 1, 1], 8))

    // [0, 0, 0, 1, 1, 1, 1, 0]
    console.log(shiftLeft([0, 0, 0, 0, 1, 1, 1, 1], 1))

    // [1, 1, 1, 1, 0, 0, 0, 0]
    console.log(shiftLeft([0, 0, 0, 0, 1, 1, 1, 1], 4))

    // [1, 0, 0, 0, 0, 0, 0, 0]
    console.log(shiftLeft([0, 0, 0, 0, 1, 1, 1, 1], 7))
}

function test1() {
    function bitwiseOr(byte1, byte2) {
        let result = []
        for(let i = 0; i < byte1.length; i++) {
            if(byte1[i] === 1 || byte2[i] === 1) {
                result.push(1)       
            } else {
                result.push(0)
            }
        }
        return result
    }

    console.log(bitwiseOr(
        [0, 0, 0, 0, 1, 1, 1, 1],
        [1, 1, 1, 1, 0, 0, 0, 0],
    )) // [1, 1, 1, 1, 1, 1, 1, 1]

    console.log(bitwiseOr(
        [0, 0, 0, 0, 1, 0, 1, 0],
        [0, 0, 0, 0, 0, 1, 0, 1],
    )) // [0, 0, 0, 0, 1, 1, 1, 1]
}

function test1() {
    function bitwiseAnd(byte1, byte2) {
        let result = []
        for(let i = 0; i < byte1.length; i++) {
            if(byte1[i] === 1 && byte2[i] === 1) {
                result.push(1)       
            } else {
                result.push(0)
            }
        }
        return result
    }

    console.log(bitwiseAnd(
        [0, 0, 0, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 0, 0, 0, 1],
    )) // [1, 1, 1, 1, 1, 1, 1, 1]

    console.log(bitwiseAnd(
        [0, 0, 0, 0, 1, 0, 1, 0],
        [0, 0, 0, 0, 0, 1, 0, 1],
    )) // [0, 0, 0, 0, 1, 1, 1, 1]
}

function test() {
    function bitwiseXor(byte1, byte2) {
        let result = []
        for(let i = 0; i < byte1.length; i++) {
            if((byte1[i] === 0 && byte2[i] === 1) || (byte1[i] === 1 && byte2[i] === 0)) {
                result.push(1)       
            } else {
                result.push(0)
            }
        }
        return result
    }

    console.log(bitwiseXor(
        [0, 0, 0, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 0, 0, 0, 1],
    )) // [1, 1, 1, 1, 1, 1, 1, 1]

    console.log(bitwiseXor(
        [0, 0, 0, 0, 1, 0, 1, 0],
        [0, 0, 0, 0, 0, 1, 0, 1],
    )) // [0, 0, 0, 0, 1, 1, 1, 1]
}
test()
