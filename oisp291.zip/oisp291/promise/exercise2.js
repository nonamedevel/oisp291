//2 promises that creating two numbers with delay of 2 and 3 seconds

class TestClass{

    constructor(promises, numbers) {
        this.initPromise();

        this.promises = [
        this.initPromise(1, 2000),
        this.initPromise(3, 3000),
        this.initPromise(2, 3000),
        ];

        this.numbers = [];

        this.outputError(this.promises);
        this.callbackNumbers(this.numbers);
    }

    initPromise(number, time) {
         return new Promise (function(res, rej) {
            setTimeout(function() {
                res(number)
            }, time)
        })
    }

    outputError(promises){
        for(const promise of promises) {
            promise.then(this.callbackNumbers).catch(function(err) {
                console.log(err)
                })
        }
    }

    callbackNumbers(num){
        this.numbers.push(num)
        if (this.numbers.length === this.promises.length) {
            let sum = 0
            for (let i=0; i < this.numbers.length; i++) {
                sum += this.numbers[i]
            }
            console.log(sum)
        }
    }
}

var obj = new TestClass();