function test1() {
    const promise = new Promise(function(res, rej) {
        res(123)
    })
    // console.log(promise)
    // console.log(promise + 2)
    promise.then(function(num) {
        console.log(num)
        console.log(num + 2)
    })
}

function test1() {
    const promise = new Promise(function(res, rej) {
        rej(456)
    })
    promise.then(function(num) {
        console.log(num)
        console.log(num + 2)
    }).catch(function(param) {
        console.log(param)
    })
}

function test() {
    const promise = new Promise(function(res, rej) {
        console.log('start')
        // res(123)
        // rej(456)
        setTimeout(function() {
            res(333)
        }, 2000)
    })
    promise.then(function(num) {
        console.log(num)
        console.log(num + 2)
    }).catch(function(param) {
        console.log(param)
    }).finally(function() {
        console.log('the end')
    })
    // console.log('the end')
}

test()