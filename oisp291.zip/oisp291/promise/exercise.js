//2 promises that creating two numbers with delay of 2 and 3 seconds

async function test() {
    function createPromise(number, time){
        return new Promise (function(res, rej) {
            setTimeout(function() {
                res(number)
            }, time)
        })
    }
    const promises = [
        createPromise(1,2000),
        createPromise(2,3000),
        createPromise(2,3000),
    ]
    for(const promise of promises){
        promise.then(callback).catch(function(err) {
            console.log(err)
        })
    }

    const numbers = []
    function callback(num) {
        numbers.push(num)
        if (numbers.length === promises.length) {
            let sum = 0
            for (let i=0; i < numbers.length; i++) {
                sum += numbers[i]
            }
            console.log(sum)
        }
    }
}
test()